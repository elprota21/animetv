package com.animetv.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.animetv.app.data.Account
import com.animetv.app.data.Brand
import com.animetv.app.data.S
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Acceso obligatorio: correo y contraseña. Sin sesión no se entra a la app. */
@Composable
fun LoginScreen(s: S, onDone: () -> Unit) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val firstFocus = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        delay(350)
        runCatching { firstFocus.requestFocus() }
    }

    fun submit(signup: Boolean) {
        if (busy) return
        val e = email.trim()
        if (e.isEmpty() || password.length < 6) {
            error = s.loginFailed
            return
        }
        busy = true
        error = null
        scope.launch {
            val r = if (signup) Account.signUp(e, password) else Account.signIn(e, password)
            busy = false
            if (r == null) onDone() else error = r
        }
    }

    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Brand.bg2, Brand.bg))),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.width(460.dp)
        ) {
            Logo(size = 92.dp)
            Spacer(Modifier.height(14.dp))
            Txt(Brand.appName, size = 34, weight = FontWeight.Bold)
            Txt(s.tagline, size = 15, color = Brand.muted)
            Spacer(Modifier.height(26.dp))

            Field(
                value = email,
                onChange = { email = it },
                hint = s.email,
                password = false,
                focusRequester = firstFocus
            )
            Spacer(Modifier.height(12.dp))
            Field(
                value = password,
                onChange = { password = it },
                hint = s.password,
                password = true
            )

            val err = error
            if (err != null) {
                Spacer(Modifier.height(12.dp))
                Txt(err, size = 14, color = Color(0xFFFF8A8A), align = androidx.compose.ui.text.style.TextAlign.Center)
            }

            Spacer(Modifier.height(20.dp))
            if (busy) {
                Spinner()
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    TvButton(s.signIn, { submit(false) }, primary = true)
                    TvButton(s.createAccount, { submit(true) })
                }
            }
        }
    }
}

@Composable
private fun Field(
    value: String,
    onChange: (String) -> Unit,
    hint: String,
    password: Boolean,
    focusRequester: FocusRequester? = null
) {
    var focused by remember { mutableStateOf(false) }
    val keyboard = LocalSoftwareKeyboardController.current
    var mod = Modifier.fillMaxWidth()
    if (focusRequester != null) mod = mod.focusRequester(focusRequester)
    BasicTextField(
        value = value,
        onValueChange = onChange,
        singleLine = true,
        textStyle = TextStyle(color = Brand.text, fontSize = 17.sp),
        visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
        modifier = mod
            .onFocusChanged { focused = it.isFocused }
            .background(Brand.surface, RoundedCornerShape(12.dp))
            .border(
                if (focused) 3.dp else 1.dp,
                if (focused) Brand.cyan else Color(0x33FFFFFF),
                RoundedCornerShape(12.dp)
            )
            .clickable { keyboard?.show() }
            .padding(horizontal = 16.dp, vertical = 14.dp),
        decorationBox = { inner ->
            Box {
                if (value.isEmpty()) {
                    Txt(hint, size = 16, color = Brand.muted)
                }
                inner()
            }
        }
    )
}
