# AnimeTV (Android TV)

App para Android TV hecha con Kotlin y Jetpack Compose. Catalogo desde una API de terceros,
reproduccion con Media3 (ExoPlayer) y reproductor WebView de respaldo.

## Obtener el APK sin instalar nada (GitHub Actions)

1. Crea un repositorio en GitHub y sube TODO el contenido de esta carpeta (incluida `.github`).
2. Ve a la pestana **Actions** > **Build APK** > **Run workflow** (tambien corre solo en cada push).
3. Cuando termine (unos 5-8 min), entra a la ejecucion y descarga el artefacto **AnimeTV-apk**.
   Dentro esta `app-debug.apk`.

## Obtener el APK con Android Studio

1. Abre la carpeta en Android Studio (Koala o superior, JDK 17) y deja que sincronice Gradle.
2. Menu **Build > Build APK(s)**. El archivo queda en `app/build/outputs/apk/debug/app-debug.apk`.

## Instalar en la TV

- Con `adb`: `adb connect IP_DE_LA_TV:5555` y luego `adb install app-debug.apk`
  (activa "Depuracion USB/ADB" en Opciones de desarrollador de la TV).
- O copia el APK a un USB / usa la app "Send Files to TV" y abrelo con un explorador de archivos.
  Hay que permitir "Instalar apps de origenes desconocidos".

## Catalogo completo

Home > boton **Catalogo**: indice A-Z con carga infinita. Recorre la busqueda de la API letra por letra y
pagina por pagina (`Repo.catalogPage`). Si la API no ofrece paginacion o rechaza busquedas de una letra,
veras el error exacto en pantalla; en ese caso hay que ajustar `catalogPage` a la ruta real.

## Novedades
- Menu lateral (Inicio, Catalogo, Buscar, Ajustes) y tu logo arriba a la derecha.
- Ficha con selector de temporadas (sigue las precuelas y secuelas de la API).
- Inicio con portadas reales y fila "Continuar viendo".
- Player con menu (calidad, velocidad, subtitulos, audio, siguiente servidor): flecha abajo.
- Fuentes: `data/Provider.kt` + `data/providers/AnimeAv1.kt`. Para anadir otra API implementa `Provider`.

## Mandos

- Home: flechas para moverte, OK para abrir. Atras vuelve a la pantalla anterior.
- Player: izquierda/derecha = +-10 s, OK = pausa, arriba = velocidad, abajo = ocultar controles.

## Si algo sale vacio

El catalogo depende de `https://animeav1.ahmedrangel.com/api` (ver `data/Brand.kt`). La app muestra el
error exacto en pantalla (por ejemplo "HTTP 404 en /list/latest-episodes"). Si cambia el dominio o las
rutas, ajusta `Brand.apiBase` y las rutas en `data/Repo.kt`.
