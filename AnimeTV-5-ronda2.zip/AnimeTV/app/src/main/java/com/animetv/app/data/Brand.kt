package com.animetv.app.data

import androidx.compose.ui.graphics.Color

object Brand {
    const val appName = "AnimeTV"
    const val appVersion = "1.2"

    // Si la API cambia de dominio, es lo unico que hay que tocar.
    const val apiBase = "https://animeav1.ahmedrangel.com/api"

    // Paleta tomada de tu logo: violeta profundo + cian
    val bg = Color(0xFF0D0620)
    val bg2 = Color(0xFF1A0B3D)
    val surface = Color(0xFF1E1245)
    val accent = Color(0xFF8B5CFF)
    val cyan = Color(0xFF3DE0E0)
    val teal = Color(0xFF3DE0E0)
    val text = Color(0xFFF1EDFF)
    val muted = Color(0xFFA79BCB)
}
