package com.animetv.app.ui

import android.graphics.Bitmap
import android.net.Uri
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.animetv.app.data.AdBlock
import com.animetv.app.data.Brand
import com.animetv.app.data.S
import kotlinx.coroutines.delay

// Intenta reproducir el <video> de la pagina nada mas detectarlo (con reintentos cortos).
private const val AUTOPLAY_JS =
    "(function(){function go(){var v=document.querySelector('video');if(v){try{var p=v.play();if(p&&p.catch){p.catch(function(){});}}catch(e){}}}go();setTimeout(go,1200);setTimeout(go,3000);})()"

private fun baseDomain(host: String?): String {
    val h = host.orEmpty()
    val p = h.split(".")
    return if (p.size >= 2) p.takeLast(2).joinToString(".") else h
}

/**
 * Reproductor de respaldo: muestra el embed original con bloqueo de anuncios y un cursor virtual
 * (flechas = mover, OK = clic) para poder cerrar lo que se cuele o usar los controles de la pagina.
 */
@Composable
fun WebPlayerScreen(
    s: S,
    embedUrl: String,
    onNextServer: (() -> Unit)?,
    onPrevEpisode: (() -> Unit)? = null,
    onNextEpisode: (() -> Unit)? = null,
    onBack: () -> Unit
) {
    var customView by remember { mutableStateOf<View?>(null) }
    var customCb by remember { mutableStateOf<WebChromeClient.CustomViewCallback?>(null) }
    var wv by remember { mutableStateOf<WebView?>(null) }
    var root by remember { mutableStateOf<FrameLayout?>(null) }

    var size by remember { mutableStateOf(IntSize.Zero) }
    var cx by remember { mutableFloatStateOf(-1f) }
    var cy by remember { mutableFloatStateOf(-1f) }
    var showHint by remember { mutableStateOf(true) }
    var cursorVisible by remember { mutableStateOf(true) }
    var lastMove by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val focus = remember { FocusRequester() }

    fun moved() {
        lastMove = System.currentTimeMillis()
        cursorVisible = true
    }

    // Saltar en el video de la pagina sin tocar el cursor.
    fun jsSeek(deltaSec: Int) {
        wv?.evaluateJavascript(
            "(function(){var v=document.querySelector('video');if(v){try{v.currentTime=Math.max(0,(v.currentTime||0)+(" + deltaSec + "));}catch(e){}}})()",
            null
        )
        moved()
    }

    fun jsPlayPause() {
        wv?.evaluateJavascript(
            "(function(){var v=document.querySelector('video');if(v){try{if(v.paused){v.play();}else{v.pause();}}catch(e){}}})()",
            null
        )
        moved()
    }

    val density = LocalDensity.current
    val btnW = with(density) { 230.dp.toPx() }
    val btnH = with(density) { 46.dp.toPx() }
    val margin = with(density) { 16.dp.toPx() }

    LaunchedEffect(size) {
        if (size.width > 0 && cx < 0f) {
            cx = size.width / 2f
            cy = size.height / 2f
        }
    }
    LaunchedEffect(Unit) {
        runCatching { focus.requestFocus() }
        delay(7000)
        showHint = false
    }
    // El cursor se oculta solo tras 3,5 s sin moverlo; cualquier tecla lo trae de vuelta.
    LaunchedEffect(Unit) {
        while (true) {
            delay(500)
            if (cursorVisible && System.currentTimeMillis() - lastMove > 3500) cursorVisible = false
        }
    }

    BackHandler {
        if (customView != null) customCb?.onCustomViewHidden() else onBack()
    }

    DisposableEffect(Unit) {
        onDispose { wv?.apply { stopLoading(); destroy() } }
    }

    fun click() {
        if (onNextServer != null &&
            cx >= margin && cx <= margin + btnW &&
            cy >= margin && cy <= margin + btnH
        ) {
            onNextServer.invoke()
            return
        }
        val target = root ?: return
        val px = cx
        val py = cy
        val t = SystemClock.uptimeMillis()
        val down = MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, px, py, 0)
        target.dispatchTouchEvent(down)
        down.recycle()
        target.postDelayed({
            val up = MotionEvent.obtain(t, SystemClock.uptimeMillis(), MotionEvent.ACTION_UP, px, py, 0)
            target.dispatchTouchEvent(up)
            up.recycle()
        }, 70)
    }

    Box(
        Modifier.fillMaxSize()
            .onSizeChanged { size = it }
            .focusRequester(focus)
            .focusable()
            .onPreviewKeyEvent { ev ->
                if (ev.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                val step = 14f + minOf(ev.nativeKeyEvent.repeatCount, 25) * 3f
                val w = size.width.toFloat()
                val h = size.height.toFloat()
                when (ev.key) {
                    Key.DirectionLeft -> { moved(); cx = (cx - step).coerceIn(0f, w); true }
                    Key.DirectionRight -> { moved(); cx = (cx + step).coerceIn(0f, w); true }
                    Key.DirectionUp -> {
                        moved()
                        if (cy <= 4f) wv?.scrollBy(0, -90)
                        cy = (cy - step).coerceIn(0f, h); true
                    }
                    Key.DirectionDown -> {
                        moved()
                        if (cy >= h - 4f) wv?.scrollBy(0, 90)
                        cy = (cy + step).coerceIn(0f, h); true
                    }
                    Key.DirectionCenter, Key.Enter, Key.NumPadEnter -> { moved(); click(); true }
                    Key.MediaFastForward -> { jsSeek(10); true }
                    Key.MediaRewind -> { jsSeek(-10); true }
                    Key.MediaPlayPause -> { jsPlayPause(); true }
                    Key.MediaNext -> { if (onNextEpisode != null) { onNextEpisode.invoke(); true } else false }
                    Key.MediaPrevious -> { if (onPrevEpisode != null) { onPrevEpisode.invoke(); true } else false }
                    else -> false
                }
            }
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { c ->
                val frame = FrameLayout(c)
                val match = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                var loadedOnce = false

                val web = WebView(c).apply {
                    isFocusable = false
                    isFocusableInTouchMode = false
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.mediaPlaybackRequiresUserGesture = false
                    settings.javaScriptCanOpenWindowsAutomatically = false
                    layoutParams = match
                    setBackgroundColor(0xFF000000.toInt())

                    webViewClient = object : WebViewClient() {
                        override fun shouldInterceptRequest(
                            view: WebView?,
                            request: WebResourceRequest?
                        ): WebResourceResponse? {
                            val u = request?.url?.toString() ?: return null
                            return if (AdBlock.isBlocked(u)) AdBlock.empty() else null
                        }

                        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                            val u = request?.url ?: return false
                            val scheme = u.scheme ?: return false
                            if (scheme != "http" && scheme != "https") return true
                            // Tras la primera carga, bloquea saltos de pagina completa a otro sitio (redirecciones de anuncios)
                            if (loadedOnce && request.isForMainFrame) {
                                val current = runCatching { Uri.parse(view?.url ?: "").host }.getOrNull()
                                if (baseDomain(u.host) != baseDomain(current)) return true
                            }
                            return false
                        }

                        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                            view?.evaluateJavascript(AdBlock.NO_POPUP_JS, null)
                            view?.evaluateJavascript(AdBlock.COSMETIC_JS, null)
                        }

                        override fun onPageFinished(view: WebView?, url: String?) {
                            loadedOnce = true
                            view?.evaluateJavascript(AdBlock.COSMETIC_JS, null)
                            // Deteccion y reproduccion automatica: en cuanto hay un <video>, dale play.
                            view?.evaluateJavascript(AUTOPLAY_JS, null)
                        }
                    }

                    webChromeClient = object : WebChromeClient() {
                        override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                            customView = view
                            customCb = callback
                            visibility = View.GONE
                            frame.addView(view, match)
                        }

                        override fun onHideCustomView() {
                            customView?.let { frame.removeView(it) }
                            customView = null
                            customCb = null
                            visibility = View.VISIBLE
                        }

                        override fun onCreateWindow(
                            view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message?
                        ): Boolean = false
                    }
                    loadUrl(embedUrl)
                }
                wv = web
                root = frame
                frame.addView(web)
                frame
            }
        )

        // Boton "Siguiente servidor" (se pulsa llevando el cursor encima y dando OK)
        if (onNextServer != null) {
            Box(
                Modifier.align(Alignment.TopStart).padding(16.dp).size(230.dp, 46.dp)
                    .background(Brand.accent, RoundedCornerShape(23.dp)),
                contentAlignment = Alignment.Center
            ) {
                Txt(s.nextServer, size = 15, weight = FontWeight.SemiBold, color = Color.White)
            }
        }

        Logo(Modifier.align(Alignment.TopEnd).padding(top = 14.dp, end = 20.dp), 38.dp, 0.55f)

        // Cursor virtual (se oculta solo cuando no se usa)
        if (cx >= 0f && cursorVisible) {
            Canvas(Modifier.fillMaxSize()) {
                drawCircle(Color.Black, radius = 15f, center = Offset(cx, cy))
                drawCircle(Color.White, radius = 12f, center = Offset(cx, cy))
                drawCircle(Brand.accent, radius = 5f, center = Offset(cx, cy))
            }
        }

        if (showHint) {
            Box(
                Modifier.align(Alignment.BottomCenter).padding(24.dp)
                    .background(Color(0xCC000000), RoundedCornerShape(10.dp))
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Txt(s.cursorHint, size = 13, color = Color.White)
            }
        }
    }
}
