package com.animetv.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONTokener
import java.io.IOException
import java.util.concurrent.TimeUnit

class ApiException(msg: String) : IOException(msg)

object Api {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()

    private const val UA =
        "Mozilla/5.0 (Linux; Android 12; TV) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

    /** Devuelve un JSONObject o un JSONArray. */
    suspend fun get(path: String): Any = withContext(Dispatchers.IO) {
        val req = Request.Builder()
            .url(Brand.apiBase + path)
            .header("User-Agent", UA)
            .header("Accept", "application/json")
            .build()

        client.newCall(req).execute().use { r ->
            val body = r.body?.string().orEmpty()
            if (!r.isSuccessful) throw ApiException("HTTP ${r.code} en $path")
            val t = body.trimStart()
            if (!t.startsWith("{") && !t.startsWith("[")) {
                throw ApiException("Respuesta no JSON en $path")
            }
            JSONTokener(body).nextValue()
        }
    }
}
