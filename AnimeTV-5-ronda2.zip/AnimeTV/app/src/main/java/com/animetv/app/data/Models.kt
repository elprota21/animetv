package com.animetv.app.data

data class Media(
    val title: String,
    val cover: String,
    val slug: String,
    val animeSlug: String,
    val type: String,
    val number: Int = 0
)

data class Ep(val number: Int, val title: String = "")

data class Related(
    val slug: String,
    val title: String,
    val relation: String,
    val cover: String,
    val year: Int
)

data class Anime(
    val slug: String,
    val title: String,
    val cover: String,
    val synopsis: String,
    val year: Int,
    val status: String,
    val type: String,
    val rating: Double,
    val genres: List<String>,
    val episodes: List<Ep>,
    val related: List<Related>
)

data class Season(val slug: String, val title: String, val year: Int)

data class Embed(val name: String, val url: String, val lang: String)
