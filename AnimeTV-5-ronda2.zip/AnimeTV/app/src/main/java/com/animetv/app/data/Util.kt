package com.animetv.app.data

import java.net.URI

fun hostKey(u: String): String =
    runCatching { URI(u).host }.getOrNull()?.removePrefix("www.").orEmpty()

/** https://animeav1.com/media/ranma-2024-3rd-season/6  ->  ranma-2024-3rd-season */
fun slugFromUrl(u: String): String =
    Regex("/media/([^/?#]+)").find(u)?.groupValues?.get(1).orEmpty()
