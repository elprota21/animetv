package com.animetv.app.data

import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream
import java.net.URI

/** Bloqueo de publicidad: red (dominios y patrones) + limpieza de capas en la pagina. */
object AdBlock {
    private val hosts = setOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
        "google-analytics.com", "googletagmanager.com", "googletagservices.com", "adnxs.com",
        "adsrvr.org", "taboola.com", "outbrain.com", "popads.net", "popcash.net", "propellerads.com",
        "propellerclick.com", "exoclick.com", "exosrv.com", "juicyads.com", "adsterra.com",
        "adsterratools.com", "highperformanceformat.com", "highrevenuegate.com", "revenuehits.com",
        "clickadu.com", "hilltopads.net", "a-ads.com", "ad-maven.com", "admaven.com", "mgid.com",
        "onclickads.net", "onclasrv.com", "pushance.com", "richpush.co", "trafficjunky.net",
        "tsyndicate.com", "realsrv.com", "bidvertiser.com", "yllix.com", "adcash.com", "clksite.com",
        "zeropark.com", "adskeeper.com", "popunderjs.com", "profitablegatecpm.com", "effectivegatecpm.com",
        "acscdn.com", "adtng.com", "trafficstars.com", "ero-advertising.com", "monetag.com",
        "pubfuture-ad.com", "rtmark.net", "yandex.ru", "mc.yandex.ru",
        "adspyglass.com", "adk2x.com", "adsco.re", "ads.pubmatic.com", "pubmatic.com", "rubiconproject.com",
        "criteo.com", "criteo.net", "amazon-adsystem.com", "adform.net", "smartadserver.com",
        "moatads.com", "scorecardresearch.com", "quantserve.com", "2mdn.net", "serving-sys.com",
        "popmyads.com", "pop-ads.net", "ad.plus", "adexchangeclear.com", "tracker-fast.com",
        "betteradsystem.com", "cdn4ads.com", "adhitzads.com", "adsession.com", "ntvpforever.com",
        "dolohen.com", "wpnsrv.com", "pushwhy.com", "notix.io", "vidazoo.com", "adsafeprotected.com"
    )

    private val pathHints = listOf("popunder", "adsbygoogle", "/adserver", "/prebid", "/popads", "/vast.xml", "/pop.js")

    fun isBlocked(url: String): Boolean {
        val l = url.lowercase()
        val host = runCatching { URI(l).host }.getOrNull().orEmpty()
        if (host.isNotEmpty() && hosts.any { host == it || host.endsWith(".$it") }) return true
        return pathHints.any { l.contains(it) }
    }

    fun empty() = WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))

    /** Anula window.open (popups) dentro de la pagina. */
    const val NO_POPUP_JS = "window.open=function(){return null};"

    /**
     * Quita capas de anuncio: elementos fijos/absolutos de pantalla casi completa con z-index alto
     * (los que tapan el video o roban el primer clic) y bloques con nombre de anuncio.
     * No toca nada que contenga un <video> ni lo que parezca una verificacion (captcha).
     */
    const val COSMETIC_JS = """
(function(){
  if (window.__ntvc) return; window.__ntvc = 1;
  var SAFE = /captcha|turnstile|challenges\.cloudflare|hcaptcha|recaptcha/i;
  var PLAYER = /vjs|jw-|plyr|video-js|player|controls/i;
  var AD = /(^|[-_ ])(ads?|adv|advert|advertisement|banner|popup|popunder|interstitial)([-_ 0-9]|$)/i;
  function txt(el){ return (el.id||'') + ' ' + ((el.className && el.className.toString()) || ''); }
  function hasVideo(el){ try { return el.tagName === 'VIDEO' || !!el.querySelector('video'); } catch(e){ return false; } }
  function safe(el){
    try {
      if (SAFE.test(txt(el)) || SAFE.test(el.src || '')) return true;
      return !!el.querySelector('iframe[src*="captcha"],iframe[src*="turnstile"],iframe[src*="challenges"],[class*="captcha"],[id*="captcha"]');
    } catch(e){ return false; }
  }
  function sweep(){
    var vw = window.innerWidth, vh = window.innerHeight;
    var all = document.querySelectorAll('div,iframe,a,section,aside,ins,span');
    for (var i = 0; i < all.length; i++) {
      var el = all[i];
      if (el.__ntvk) continue;
      if (hasVideo(el) || safe(el)) { el.__ntvk = 1; continue; }
      var cs = getComputedStyle(el);
      var pos = cs.position;
      var z = parseInt(cs.zIndex) || 0;
      var r = el.getBoundingClientRect();
      var big = r.width >= vw * 0.5 && r.height >= vh * 0.5;
      var cls = txt(el);
      var adLike = AD.test(cls) && !PLAYER.test(cls);
      var floating = (pos === 'fixed' || pos === 'absolute');
      if ((floating && z >= 1000 && big) || (adLike && (floating || el.tagName === 'IFRAME' || el.tagName === 'INS'))) {
        if (el.parentNode) el.parentNode.removeChild(el);
      }
    }
  }
  setInterval(sweep, 800);
  window.open = function(){ return null; };
})();
"""

    /** Pulsa el boton de play del embed (varios reproductores no sueltan el video hasta que alguien lo hace). */
    const val AUTOPLAY_JS = """
(function(){
  if (window.__ntvp) return; window.__ntvp = 1;
  var n = 0;
  function tryPlay(){
    n++;
    try {
      var v = document.querySelector('video');
      if (v) { v.muted = true; var p = v.play(); if (p && p.catch) p.catch(function(){}); }
      var sels = ['.vjs-big-play-button','.jw-icon-display','.jw-display-icon-container','.plyr__control--overlaid',
        '.play-button','.btn-play','#play','button[aria-label*="lay"]','div[class*="play-btn"]','div[class*="play_button"]',
        '.fp-play','.mejs__overlay-button','video'];
      for (var i = 0; i < sels.length; i++) {
        var e = document.querySelector(sels[i]);
        if (e && e.click) e.click();
      }
    } catch(e){}
    if (n < 12) setTimeout(tryPlay, 900);
  }
  setTimeout(tryPlay, 600);
})();
"""
}
