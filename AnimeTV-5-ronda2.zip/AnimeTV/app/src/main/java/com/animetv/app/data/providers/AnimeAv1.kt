package com.animetv.app.data.providers

import com.animetv.app.data.*
import kotlinx.coroutines.CancellationException
import org.json.JSONArray
import org.json.JSONObject
import java.net.URI
import java.net.URLEncoder

object AnimeAv1 : Provider {
    override val id = "animeav1"
    override val label = "AnimeAV1"

    // ---------- cache en memoria ----------
    private val cache = HashMap<String, Pair<Long, Any>>()

    @Suppress("UNCHECKED_CAST")
    private suspend fun <T : Any> cached(key: String, ttlMs: Long, load: suspend () -> T): T {
        val hit = cache[key]
        if (hit != null && System.currentTimeMillis() - hit.first < ttlMs) return hit.second as T
        return load().also { cache[key] = System.currentTimeMillis() to it }
    }

    override fun cachedAnime(slug: String): Anime? = cache["anime:$slug"]?.second as? Anime

    /** Prueba varias rutas hasta que una responda y se pueda interpretar. */
    private suspend fun <T> firstOf(vararg paths: String, parse: (Any) -> T): T {
        var last: Throwable? = null
        for (p in paths) {
            try {
                return parse(Api.get(p))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                last = e
            }
        }
        throw last ?: ApiException("Sin respuesta")
    }

    // ---------- helpers ----------
    private fun fixUrl(u: String): String = if (u.startsWith("//")) "https:$u" else u

    private fun hostOf(u: String): String =
        runCatching { URI(u).host }.getOrNull()?.removePrefix("www.")?.takeIf { it.isNotEmpty() } ?: "Servidor"

    private fun unwrapArray(v: Any?): JSONArray? = when (v) {
        is JSONArray -> v
        is JSONObject ->
            v.arr("media", "results", "animes", "episodes", "list", "items")
                ?: v.obj("data")?.let { unwrapArray(it) }
                ?: v.arr("data")
        else -> null
    }

    private fun unwrapObject(v: Any?): JSONObject? = when (v) {
        is JSONObject -> v.obj("data") ?: v
        else -> null
    }

    private fun parseMedia(arr: JSONArray?): List<Media> {
        if (arr == null) return emptyList()
        val out = mutableListOf<Media>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val title = o.str("title", "name")
            val slug = o.str("slug", "id")
            if (title.isEmpty() || slug.isEmpty()) continue
            val number = o.int("number", "episode", "episodeNumber")
            // La URL ("/media/<anime>/<n>") trae el slug exacto del anime.
            val animeSlug = slugFromUrl(o.str("url"))
                .ifEmpty { o.str("animeSlug", "anime_slug") }
                .ifEmpty { o.obj("anime")?.str("slug").orEmpty() }
                .ifEmpty { if (number > 0) slug.removeSuffix("-$number") else slug }
            out.add(
                Media(
                    title = title,
                    cover = fixUrl(o.str("cover", "image", "poster", "thumbnail")),
                    slug = slug,
                    animeSlug = animeSlug,
                    type = o.str("type"),
                    number = number
                )
            )
        }
        return out
    }

    private fun parseAnime(root: Any, requested: String): Anime {
        val d = unwrapObject(root) ?: throw ApiException("Ficha vacia")
        val title = d.str("title", "name")
        if (title.isEmpty()) throw ApiException("Ficha sin titulo")

        val genres = mutableListOf<String>()
        d.arr("genres")?.let { g ->
            for (i in 0 until g.length()) {
                when (val x = g.opt(i)) {
                    is String -> genres.add(x)
                    is JSONObject -> x.str("name", "title").takeIf { it.isNotEmpty() }?.let { genres.add(it) }
                }
            }
        }

        val eps = mutableListOf<Ep>()
        when (val e = d.opt("episodes")) {
            is JSONArray -> for (i in 0 until e.length()) {
                when (val x = e.opt(i)) {
                    is JSONObject -> {
                        val n = x.int("number", "episode")
                        if (n > 0) eps.add(Ep(n, x.str("title", "name")))
                    }
                    is Number -> eps.add(Ep(x.toInt()))
                }
            }
            is Number -> for (n in 1..e.toInt()) eps.add(Ep(n))
        }
        if (eps.isEmpty()) {
            for (n in 1..d.int("episodesCount", "totalEpisodes", "episodes_count")) eps.add(Ep(n))
        }

        val related = mutableListOf<Related>()
        d.arr("related")?.let { r ->
            for (i in 0 until r.length()) {
                val o = r.optJSONObject(i) ?: continue
                val s = o.str("slug").ifEmpty { slugFromUrl(o.str("url")) }
                if (s.isEmpty()) continue
                related.add(
                    Related(s, o.str("title", "name"), o.str("relation"), fixUrl(o.str("cover")), o.int("year"))
                )
            }
        }

        val rating = (d.opt("rating") as? Number)?.toDouble() ?: 0.0

        return Anime(
            slug = d.str("slug").ifEmpty { requested },
            title = title,
            cover = fixUrl(d.str("cover", "image", "poster")),
            synopsis = d.str("synopsis", "description", "sinopsis"),
            year = d.int("year"),
            status = d.str("status", "state"),
            type = d.str("type"),
            rating = rating,
            genres = genres,
            episodes = eps.distinctBy { it.number }.sortedBy { it.number },
            related = related
        )
    }

    private fun parseEmbeds(root: Any): List<Embed> {
        val d = unwrapObject(root) ?: return emptyList()
        val out = mutableListOf<Embed>()

        fun add(o: JSONObject, lang: String) {
            val url = o.str("url", "link", "embed", "src")
            if (url.isEmpty()) return
            val l = o.str("type", "lang", "language").ifEmpty { lang }.ifEmpty { "SUB" }
            out.add(Embed(o.str("name", "server", "provider").ifEmpty { hostOf(url) }, fixUrl(url), l.uppercase()))
        }

        when (val e = d.opt("embeds") ?: d.opt("servers")) {
            is JSONArray -> for (i in 0 until e.length()) e.optJSONObject(i)?.let { add(it, "") }
            is JSONObject -> e.keys().forEach { k ->
                e.optJSONArray(k)?.let { a ->
                    for (i in 0 until a.length()) a.optJSONObject(i)?.let { add(it, k) }
                }
            }
        }

        // Los HLS de zilla-networks son los que mejor se resuelven: primero.
        return out.sortedWith(
            compareBy({ if (it.url.contains("zilla", ignoreCase = true)) 0 else 1 }, { it.lang })
        )
    }

    // ---------- Provider ----------
    override suspend fun onAir(): List<Media> = cached("onair", 5 * 60_000L) {
        firstOf("/list/animes-on-air") { parseMedia(unwrapArray(it)) }
    }

    override suspend fun latest(): List<Media> = cached("latest", 5 * 60_000L) {
        firstOf("/list/latest-episodes") { parseMedia(unwrapArray(it)) }
    }

    override suspend fun search(q: String, page: Int): List<Media> {
        if (q.isBlank()) return emptyList()
        val e = URLEncoder.encode(q.trim(), "UTF-8")
        val pg = if (page > 1) "&page=$page" else ""
        return firstOf("/search?query=$e$pg", "/search?q=$e$pg") { parseMedia(unwrapArray(it)) }
    }

    override suspend fun anime(slug: String): Anime = cached("anime:$slug", 10 * 60_000L) {
        firstOf("/anime/$slug") { parseAnime(it, slug) }
    }

    override suspend fun embeds(slug: String, episode: Int): List<Embed> =
        firstOf(
            "/anime/$slug/$episode",
            "/anime/$slug/episode/$episode",
            "/anime/$slug/episodes/$episode"
        ) { v ->
            parseEmbeds(v).also { if (it.isEmpty()) throw ApiException("Sin servidores") }
        }
}
