package com.animetv.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.animetv.app.data.Brand
import com.animetv.app.data.Media
import com.animetv.app.data.Repo
import com.animetv.app.data.S
import kotlinx.coroutines.delay

@Composable
fun SearchScreen(s: S, onOpen: (Media) -> Unit) {
    var q by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Media>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var fieldFocused by remember { mutableStateOf(false) }
    val fr = remember { FocusRequester() }
    val shape = RoundedCornerShape(12.dp)

    LaunchedEffect(Unit) { runCatching { fr.requestFocus() } }

    LaunchedEffect(q) {
        error = null
        if (q.isBlank()) {
            results = emptyList()
            loading = false
            return@LaunchedEffect
        }
        delay(400) // debounce
        loading = true
        val r = runCatching { Repo.search(q) }
        results = r.getOrDefault(emptyList())
        error = r.exceptionOrNull()?.message
        loading = false
    }

    Column(Modifier.fillMaxSize().padding(top = 24.dp)) {
        Row(
            Modifier.fillMaxWidth().padding(start = 32.dp, end = 84.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                Modifier.weight(1f)
                    .clip(shape)
                    .background(Brand.surface)
                    .border(2.dp, if (fieldFocused) Brand.accent else Color.Transparent, shape)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                BasicTextField(
                    value = q,
                    onValueChange = { q = it },
                    singleLine = true,
                    textStyle = TextStyle(fontSize = 20.sp, color = Brand.text),
                    cursorBrush = SolidColor(Brand.accent),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    modifier = Modifier.fillMaxWidth().focusRequester(fr).onFocusChanged { fieldFocused = it.isFocused },
                    decorationBox = { inner ->
                        Box {
                            if (q.isEmpty()) Txt(s.searchHint, size = 20, color = Brand.muted)
                            inner()
                        }
                    }
                )
            }
        }

        Spacer(Modifier.height(8.dp))

        when {
            loading -> Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) { Spinner() }
            error != null -> Column(Modifier.padding(horizontal = 32.dp, vertical = 24.dp)) {
                Txt(s.loadError, size = 18, weight = FontWeight.Bold)
                Txt(error ?: "", size = 13, color = Brand.muted)
            }
            results.isEmpty() && q.isNotBlank() -> Box(
                Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center
            ) { Txt(s.noResults, size = 18, color = Brand.muted) }
            else -> LazyVerticalGrid(
                columns = GridCells.Adaptive(140.dp),
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 32.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(results) { item -> PosterCard(item, onOpen) }
            }
        }
    }
}
