package com.animetv.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.animetv.app.data.Brand
import com.animetv.app.data.Media
import com.animetv.app.data.Repo
import com.animetv.app.data.S
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay

/** Quita acentos y pasa a minusculas para comparar generos vengan como vengan de la API. */
private fun norm(x: String): String = x.lowercase().trim()
    .replace("á", "a").replace("é", "e").replace("í", "i")
    .replace("ó", "o").replace("ú", "u").replace("ñ", "n")

private val GENRE_ALIASES = mapOf(
    "accion" to listOf("accion", "action"),
    "aventura" to listOf("aventura", "adventure"),
    "comedia" to listOf("comedia", "comedy"),
    "drama" to listOf("drama"),
    "romance" to listOf("romance"),
    "fantasia" to listOf("fantasia", "fantasy"),
    "ciencia ficcion" to listOf("ciencia ficcion", "sci-fi", "scifi", "science fiction"),
    "terror" to listOf("terror", "horror"),
    "misterio" to listOf("misterio", "mystery"),
    "deportes" to listOf("deportes", "deporte", "sports")
)

private val KIDS_KEYS = listOf(
    "kids", "infantil", "kodomo", "children", "ninos", "familiar", "family"
)

/**
 * Pantalla de un genero (o de Kids): explora un grupo de candidatos del catalogo,
 * pide su ficha y se queda con los que coinciden. La API no tiene endpoint de
 * generos, por eso se resuelve en el cliente con las fichas ya cacheadas.
 */
@Composable
fun GenreScreen(
    s: S,
    genre: String?,
    kids: Boolean,
    onOpen: (Media) -> Unit,
    onBack: (() -> Unit)? = null
) {
    var results by remember(genre, kids) { mutableStateOf<List<Media>>(emptyList()) }
    var loading by remember(genre, kids) { mutableStateOf(true) }
    var scanned by remember(genre, kids) { mutableIntStateOf(0) }
    var attempt by remember(genre, kids) { mutableIntStateOf(0) }
    val firstFocus = remember { FocusRequester() }

    LaunchedEffect(genre, kids, attempt) {
        loading = true
        results = emptyList()
        scanned = 0

        val pool = LinkedHashMap<String, Media>()
        runCatching { Repo.latest() }.getOrDefault(emptyList())
            .forEach { pool[it.animeSlug] = it }
        runCatching { Repo.onAir() }.getOrDefault(emptyList())
            .forEach { pool[it.animeSlug] = it }
        for (letter in listOf("a", "e", "i", "o", "s", "n", "t", "m")) {
            if (pool.size >= 60) break
            runCatching { Repo.catalogPage(letter, 1) }.getOrDefault(emptyList())
                .forEach { pool[it.animeSlug] = it }
        }

        val keys = if (kids) KIDS_KEYS
        else GENRE_ALIASES[norm(genre ?: "")] ?: listOf(norm(genre ?: ""))
        val found = mutableListOf<Media>()
        val candidates = pool.values.take(60)
        for (chunk in candidates.chunked(6)) {
            val details = chunk.map { m ->
                async { m to runCatching { Repo.anime(m.animeSlug) }.getOrNull() }
            }.awaitAll()
            for ((m, a) in details) {
                scanned++
                if (a == null) continue
                val gs = a.genres.map { norm(it) }
                val hit = gs.any { g -> keys.any { k -> g == k || g.contains(k) } }
                if (hit) found.add(Media(a.title, a.cover, a.slug, a.slug, "poster", 0))
                else if (m.animeSlug == a.slug) Unit
            }
            results = found.toList()
        }
        loading = false
    }

    LaunchedEffect(loading) {
        if (!loading && results.isNotEmpty()) {
            delay(200)
            runCatching { firstFocus.requestFocus() }
        }
    }

    Column(Modifier.fillMaxSize().background(Brand.bg)) {
        Row(
            Modifier.fillMaxWidth().padding(start = 32.dp, end = 32.dp, top = 24.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Txt(
                if (kids) "🧒 ${s.kids}" else (genre ?: ""),
                size = 26,
                weight = FontWeight.Bold
            )
            Spacer(Modifier.weight(1f))
            if (onBack != null) TvButton(s.back, onBack)
        }

        when {
            loading && results.isEmpty() -> Box(
                Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Spinner()
                    Spacer(Modifier.height(14.dp))
                    Txt("${s.loading} · $scanned", size = 14, color = Brand.muted)
                }
            }
            !loading && results.isEmpty() -> Column(
                Modifier.fillMaxSize().padding(horizontal = 32.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Txt(s.noResults, size = 20, weight = FontWeight.Bold)
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    TvButton(s.retry, { attempt++ }, primary = true)
                    if (onBack != null) TvButton(s.back, onBack)
                }
            }
            else -> LazyVerticalGrid(
                columns = GridCells.Adaptive(148.dp),
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 32.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                itemsIndexed(results) { i, item ->
                    PosterCard(item, onOpen, focusRequester = if (i == 0) firstFocus else null)
                }
            }
        }
    }
}
