package com.animetv.app.data

import com.animetv.app.data.providers.AnimeAv1

/**
 * Una fuente de catalogo. La UI no conoce URLs de fuentes: solo pide datos a Repo,
 * que usa el proveedor principal. Para anadir otra API: crea un archivo en data/providers,
 * implementa Provider y anadelo a Registry.
 */
interface Provider {
    val id: String
    val label: String
    suspend fun onAir(): List<Media>
    suspend fun latest(): List<Media>
    suspend fun search(q: String, page: Int = 1): List<Media>
    suspend fun anime(slug: String): Anime
    suspend fun embeds(slug: String, episode: Int): List<Embed>
    fun cachedAnime(slug: String): Anime?
}

object Registry {
    private val list = mutableListOf<Provider>(AnimeAv1)
    val providers: List<Provider> get() = list.toList()
    val primary: Provider get() = list.first()
    fun register(p: Provider) { list.add(p) }
}
