package com.animetv.app.data

import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit

/** Fachada que usa la UI. Todo pasa por el proveedor principal (Registry). */
object Repo {
    private val p: Provider get() = Registry.primary

    suspend fun onAir(): List<Media> = p.onAir()
    suspend fun latest(): List<Media> = p.latest()
    suspend fun search(q: String): List<Media> = p.search(q, 1)

    /** Una pagina del catalogo recorriendo la busqueda por letra. */
    suspend fun catalogPage(letter: String, page: Int): List<Media> {
        val q = if (letter == "#") "1" else letter.lowercase()
        return p.search(q, page)
    }

    suspend fun anime(slug: String): Anime = p.anime(slug)
    suspend fun embeds(slug: String, episode: Int): List<Embed> = p.embeds(slug, episode)

    // ---------- portadas ----------
    private val gate = Semaphore(4)

    /** Poster del anime (no el fotograma del episodio). Limita las peticiones simultaneas. */
    suspend fun poster(slug: String): String? =
        gate.withPermit { runCatching { p.anime(slug).cover }.getOrNull() }?.takeIf { it.isNotEmpty() }

    fun posterCached(slug: String): String? = p.cachedAnime(slug)?.cover?.takeIf { it.isNotEmpty() }

    // ---------- temporadas ----------
    private fun rel(a: Anime, kinds: List<String>): Related? =
        a.related.firstOrNull { r -> kinds.any { r.relation.contains(it, ignoreCase = true) } }

    private val notSeason = Regex("movie|pel[ií]cula|special|especial|ova", RegexOption.IGNORE_CASE)

    /**
     * Cadena de temporadas: retrocede por precuelas hasta la primera y avanza por secuelas.
     * Las peliculas y especiales se saltan (pero se sigue su cadena).
     */
    suspend fun seasons(slug: String): List<Season> {
        var cur = anime(slug)
        val back = HashSet<String>()
        back.add(cur.slug)
        var guard = 0
        while (guard++ < 12) {
            val prev = rel(cur, listOf("precuela", "prequel")) ?: break
            if (!back.add(prev.slug)) break
            cur = runCatching { anime(prev.slug) }.getOrNull() ?: break
        }

        val out = mutableListOf(Season(cur.slug, cur.title, cur.year))
        val fwd = HashSet<String>()
        fwd.add(cur.slug)
        guard = 0
        while (guard++ < 14) {
            val next = rel(cur, listOf("secuela", "sequel")) ?: break
            if (!fwd.add(next.slug)) break
            val a = runCatching { anime(next.slug) }.getOrNull() ?: break
            if (!notSeason.containsMatchIn(a.type)) out.add(Season(a.slug, a.title, a.year))
            cur = a
        }
        return out
    }
}
