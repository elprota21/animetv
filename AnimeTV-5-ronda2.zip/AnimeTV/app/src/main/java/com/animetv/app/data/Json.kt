package com.animetv.app.data

import org.json.JSONArray
import org.json.JSONObject

// Lectores tolerantes: prueban varios nombres de campo por si la API los llama distinto.

fun JSONObject.str(vararg keys: String): String {
    for (k in keys) {
        if (isNull(k)) continue
        val v = opt(k)
        if (v is String && v.isNotBlank()) return v
        if (v is Number) return v.toString()
    }
    return ""
}

fun JSONObject.int(vararg keys: String): Int {
    for (k in keys) {
        if (isNull(k)) continue
        when (val v = opt(k)) {
            is Number -> return v.toInt()
            is String -> v.trim().toIntOrNull()?.let { return it }
        }
    }
    return 0
}

fun JSONObject.arr(vararg keys: String): JSONArray? {
    for (k in keys) optJSONArray(k)?.let { return it }
    return null
}

fun JSONObject.obj(vararg keys: String): JSONObject? {
    for (k in keys) optJSONObject(k)?.let { return it }
    return null
}
