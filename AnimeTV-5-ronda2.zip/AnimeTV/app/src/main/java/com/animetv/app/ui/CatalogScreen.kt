package com.animetv.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.animetv.app.data.Brand
import com.animetv.app.data.Media
import com.animetv.app.data.Repo
import com.animetv.app.data.S
import kotlinx.coroutines.delay
import java.text.Normalizer

private val LETTERS = listOf("#") + ('A'..'Z').map { it.toString() }

private fun matches(title: String, letter: String): Boolean {
    val c = title.firstOrNull { it.isLetterOrDigit() } ?: return letter == "#"
    if (letter == "#") return c.isDigit()
    val base = Normalizer.normalize(c.toString(), Normalizer.Form.NFD).first()
    return base.uppercaseChar().toString() == letter
}

/** Catalogo completo: indice A-Z + carga infinita. */
@Composable
fun CatalogScreen(s: S, onOpen: (Media) -> Unit) {
    var letter by remember { mutableStateOf("A") }
    var more by remember { mutableIntStateOf(0) }
    var tick by remember { mutableIntStateOf(0) }
    var items by remember { mutableStateOf<List<Media>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var ended by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var page by remember { mutableIntStateOf(1) }
    val seen = remember { HashSet<String>() }
    val gridState = rememberLazyGridState()
    val chipFocus = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        delay(250)
        runCatching { chipFocus.requestFocus() }
    }

    // Carga: al cambiar de letra reinicia; con "more" pide la siguiente tanda.
    LaunchedEffect(letter, more, tick) {
        if (more == 0) {
            items = emptyList()
            seen.clear()
            page = 1
            ended = false
            error = null
        }
        loading = true
        var added = 0
        var tries = 0
        while (added < 24 && tries < 8 && !ended) {
            tries++
            val r = runCatching { Repo.catalogPage(letter, page) }
            if (r.isFailure) {
                error = r.exceptionOrNull()?.message
                ended = true
                break
            }
            val fresh = r.getOrDefault(emptyList()).filter { seen.add(it.slug) }
            if (fresh.isEmpty()) {
                ended = true
                break
            }
            page++
            val m = fresh.filter { matches(it.title, letter) }
            items = items + m
            added += m.size
        }
        loading = false
    }

    // Scroll infinito
    LaunchedEffect(gridState) {
        snapshotFlow { gridState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0 }
            .collect { last ->
                if (items.isNotEmpty() && last >= items.size - 8 && !loading && !ended) more++
            }
    }

    Column(Modifier.fillMaxSize().padding(top = 22.dp)) {
        Column(Modifier.padding(start = 32.dp, end = 84.dp)) {
            Txt(s.catalog, size = 28, weight = FontWeight.Bold)
            Txt(s.catalogHint, size = 13, color = Brand.muted)
        }

        LazyRow(
            contentPadding = PaddingValues(horizontal = 32.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(LETTERS) { l ->
                FocusSurface(
                    onClick = { letter = l; more = 0 },
                    modifier = Modifier.width(38.dp).height(38.dp),
                    shape = RoundedCornerShape(10.dp),
                    focusScale = 1.1f,
                    focusRequester = if (l == "A") chipFocus else null
                ) { focused ->
                    Box(
                        Modifier.fillMaxSize().background(
                            if (focused || l == letter) Brand.accent else Brand.surface
                        ),
                        contentAlignment = Alignment.Center
                    ) {
                        Txt(l, size = 15, weight = FontWeight.Bold, align = TextAlign.Center)
                    }
                }
            }
        }

        when {
            items.isEmpty() && loading -> Box(
                Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center
            ) { Spinner() }

            items.isEmpty() -> Column(
                Modifier.fillMaxWidth().weight(1f).padding(horizontal = 32.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Txt(if (error != null) s.loadError else s.noResults, size = 20, weight = FontWeight.Bold)
                if (error != null) Txt(error ?: "", size = 13, color = Brand.muted)
                Spacer(Modifier.height(14.dp))
                TvButton(s.retry, { more = 0; tick++ }, primary = true)
            }

            else -> LazyVerticalGrid(
                state = gridState,
                columns = GridCells.Adaptive(140.dp),
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 32.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(items) { m -> PosterCard(m, onOpen) }
                if (loading) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) { Spinner() }
                    }
                }
            }
        }
    }
}
