package com.animetv.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("animetv", Context.MODE_PRIVATE)

    var lang: String
        get() = sp.getString("lang", "es") ?: "es"
        set(v) { sp.edit().putString("lang", v).apply() }

    /** Audio preferido: SUB o DUB. */
    var audio: String
        get() = sp.getString("audio", "SUB") ?: "SUB"
        set(v) { sp.edit().putString("audio", v).apply() }

    /** Ultimo servidor que reprodujo bien: se prueba primero. */
    var goodHost: String
        get() = sp.getString("goodHost", "") ?: ""
        set(v) { sp.edit().putString("goodHost", v).apply() }

    fun position(key: String): Long = sp.getLong("pos_$key", 0L)

    fun savePosition(key: String, ms: Long) {
        sp.edit().putLong("pos_$key", ms).apply()
    }

    fun hasProgress(key: String): Boolean = position(key) > 10_000L

    // ---------- capitulos vistos (terminados) ----------
    fun markWatched(key: String) {
        val set = HashSet(sp.getStringSet("watched", emptySet()) ?: emptySet())
        set.add(key)
        sp.edit().putStringSet("watched", set).apply()
    }

    fun isWatched(key: String): Boolean = (sp.getStringSet("watched", emptySet()) ?: emptySet()).contains(key)

    // ---------- me gusta (local) ----------
    fun toggleLike(slug: String): Boolean {
        val set = HashSet(sp.getStringSet("likes", emptySet()) ?: emptySet())
        val now = if (set.contains(slug)) { set.remove(slug); false } else { set.add(slug); true }
        sp.edit().putStringSet("likes", set).apply()
        return now
    }

    fun isLiked(slug: String): Boolean = (sp.getStringSet("likes", emptySet()) ?: emptySet()).contains(slug)

    // ---------- mi lista (ver mas tarde, local) ----------
    fun savedList(): List<Media> = runCatching {
        val arr = JSONArray(sp.getString("saved", "[]") ?: "[]")
        (0 until arr.length()).mapNotNull { i ->
            arr.optJSONObject(i)?.let { o ->
                Media(o.optString("t"), o.optString("c"), o.optString("s"), o.optString("s"), "poster", 0)
            }
        }
    }.getOrDefault(emptyList())

    fun isSaved(slug: String): Boolean = savedList().any { it.animeSlug == slug }

    fun toggleSaved(m: Media): Boolean {
        val cur = savedList()
        val now = if (cur.any { it.animeSlug == m.animeSlug }) {
            val arr = JSONArray()
            cur.filter { it.animeSlug != m.animeSlug }.forEach {
                arr.put(JSONObject().put("t", it.title).put("c", it.cover).put("s", it.animeSlug))
            }
            sp.edit().putString("saved", arr.toString()).apply()
            false
        } else {
            val arr = JSONArray()
            (listOf(m) + cur).take(30).forEach {
                arr.put(JSONObject().put("t", it.title).put("c", it.cover).put("s", it.animeSlug))
            }
            sp.edit().putString("saved", arr.toString()).apply()
            true
        }
        return now
    }

    // ---------- continuar viendo ----------
    fun recent(): List<Media> = runCatching {
        val arr = JSONArray(sp.getString("recent", "[]") ?: "[]")
        (0 until arr.length()).mapNotNull { i ->
            arr.optJSONObject(i)?.let { o ->
                Media(
                    title = o.optString("t"),
                    cover = o.optString("c"),
                    slug = o.optString("s"),
                    animeSlug = o.optString("s"),
                    type = "poster",
                    number = o.optInt("n")
                )
            }
        }
    }.getOrDefault(emptyList())

    fun addRecent(m: Media) {
        val list = (listOf(m) + recent().filter { it.animeSlug != m.animeSlug }).take(12)
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("t", it.title).put("c", it.cover).put("s", it.animeSlug).put("n", it.number)
            )
        }
        sp.edit().putString("recent", arr.toString()).apply()
    }
}
