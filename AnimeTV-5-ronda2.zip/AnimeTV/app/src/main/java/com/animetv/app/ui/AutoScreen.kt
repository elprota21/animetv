package com.animetv.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.animetv.app.data.Brand
import com.animetv.app.data.Embed
import com.animetv.app.data.Prefs
import com.animetv.app.data.Repo
import com.animetv.app.data.S
import com.animetv.app.data.hostKey

/** Carga los servidores del episodio y los ordena para probarlos uno tras otro. */
@Composable
fun AutoScreen(
    s: S,
    animeSlug: String,
    number: Int,
    title: String,
    prefs: Prefs,
    onReady: (List<Embed>) -> Unit,
    onBack: () -> Unit
) {
    var error by remember { mutableStateOf<String?>(null) }
    var attempt by remember { mutableIntStateOf(0) }
    val ready by rememberUpdatedState(onReady)

    LaunchedEffect(attempt) {
        error = null
        val r = runCatching { Repo.embeds(animeSlug, number) }
        val list = r.getOrDefault(emptyList())
        if (list.isEmpty()) {
            error = r.exceptionOrNull()?.message ?: s.noServers
            return@LaunchedEffect
        }
        val pref = prefs.audio
        val good = prefs.goodHost
        // Audio preferido primero, luego el ultimo servidor que funciono; el resto conserva su orden.
        ready(
            list.sortedWith(
                compareBy(
                    { if (it.lang == pref) 0 else 1 },
                    { if (good.isNotEmpty() && hostKey(it.url) == good) 0 else 1 }
                )
            )
        )
    }

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(48.dp)) {
            Txt("$title · ${s.episode} $number", size = 22, weight = FontWeight.Bold, align = TextAlign.Center, maxLines = 2)
            Spacer(Modifier.height(20.dp))
            if (error == null) {
                Spinner(Modifier.size(52.dp))
                Spacer(Modifier.height(16.dp))
                Txt(s.loading, size = 16, color = Brand.muted)
            } else {
                Txt(s.noServers, size = 18, weight = FontWeight.SemiBold)
                Txt(error ?: "", size = 13, color = Brand.muted)
            }
            Spacer(Modifier.height(20.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (error != null) TvButton(s.retry, { attempt++ }, primary = true)
                TvButton(s.back, onBack)
            }
        }
    }
}
