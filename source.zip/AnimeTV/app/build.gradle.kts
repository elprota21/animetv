plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.animetv.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.animetv.app"
        minSdk = 21
        targetSdk = 34
        versionCode = 9
        versionName = "1.3.5"
    }

    // Firma FIJA desde los secrets de GitHub (variables ANIMETV_KS_*):
    // todas las versiones salen con la misma firma y las actualizaciones
    // se instalan encima sin desinstalar. Sin variables (local), la de debug.
    signingConfigs {
        val ksFile = System.getenv("ANIMETV_KS_FILE")
        if (ksFile != null) {
            create("fixed") {
                storeFile = file(ksFile)
                storePassword = System.getenv("ANIMETV_KS_PASS")
                keyAlias = System.getenv("ANIMETV_KEY_ALIAS")
                keyPassword = System.getenv("ANIMETV_KEY_PASS")
            }
        }
    }

    buildTypes {
        debug {
            val fixed = signingConfigs.findByName("fixed")
            if (fixed != null) signingConfig = fixed
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("io.coil-kt:coil-compose:2.6.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("androidx.media3:media3-exoplayer:1.3.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.3.1")
    implementation("androidx.media3:media3-ui:1.3.1")
}
