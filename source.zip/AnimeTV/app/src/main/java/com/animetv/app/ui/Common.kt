package com.animetv.app.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import coil.compose.AsyncImage
import com.animetv.app.R
import com.animetv.app.data.Anime
import com.animetv.app.data.Brand
import com.animetv.app.data.Media
import com.animetv.app.data.Repo

@Composable
fun Txt(
    text: String,
    modifier: Modifier = Modifier,
    size: Int = 14,
    color: Color = Brand.text,
    weight: FontWeight? = null,
    maxLines: Int = Int.MAX_VALUE,
    lineHeight: Int = 0,
    align: TextAlign = TextAlign.Unspecified
) {
    BasicText(
        text = text,
        modifier = modifier,
        style = TextStyle(
            color = color,
            fontSize = size.sp,
            fontWeight = weight,
            lineHeight = if (lineHeight > 0) lineHeight.sp else TextUnit.Unspecified,
            textAlign = align
        ),
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis
    )
}

/** Tu logo (esquina superior derecha, marca de agua en el video, etc.). */
@Composable
fun Logo(modifier: Modifier = Modifier, size: Dp = 44.dp, alpha: Float = 1f) {
    Image(
        painter = painterResource(R.drawable.logo_mark),
        contentDescription = "AnimeTV",
        modifier = modifier.size(size).alpha(alpha).clip(RoundedCornerShape(size * 0.22f))
    )
}

@Composable
fun Spinner(modifier: Modifier = Modifier.size(40.dp), color: Color = Brand.cyan) {
    val t = rememberInfiniteTransition(label = "spin")
    val angle by t.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(900, easing = LinearEasing)),
        label = "angle"
    )
    Canvas(modifier) {
        val w = size.minDimension * 0.12f
        drawArc(
            color = color,
            startAngle = angle,
            sweepAngle = 270f,
            useCenter = false,
            topLeft = Offset(w / 2, w / 2),
            size = Size(size.width - w, size.height - w),
            style = Stroke(width = w, cap = StrokeCap.Round)
        )
    }
}

/** Contenedor enfocable con escala y borde al recibir foco (control remoto). */
@Composable
fun FocusSurface(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(14.dp),
    focusScale: Float = 1.06f,
    focusRequester: FocusRequester? = null,
    onFocused: () -> Unit = {},
    content: @Composable BoxScope.(Boolean) -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) focusScale else 1f, label = "focusScale")
    val base = if (focusRequester != null) modifier.focusRequester(focusRequester) else modifier

    Box(
        base
            .zIndex(if (focused) 1f else 0f)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .onFocusChanged { st ->
                focused = st.isFocused
                if (st.isFocused) onFocused()
            }
            .border(if (focused) 3.dp else 0.dp, if (focused) Brand.cyan else Color.Transparent, shape)
            .clip(shape)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
    ) { content(focused) }
}

@Composable
fun TvButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    primary: Boolean = false,
    focusRequester: FocusRequester? = null
) {
    FocusSurface(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(50),
        focusScale = 1.05f,
        focusRequester = focusRequester
    ) { focused ->
        Box(
            Modifier
                .background(
                    when {
                        focused -> Brand.accent
                        primary -> Color(0xFF7A4DEB)
                        else -> Color(0x2EFFFFFF)
                    }
                )
                .padding(horizontal = 22.dp, vertical = 10.dp),
            contentAlignment = Alignment.Center
        ) {
            Txt(text, size = 15, weight = FontWeight.SemiBold, color = Color.White)
        }
    }
}

@Composable
fun Badge(text: String, color: Color = Brand.accent, modifier: Modifier = Modifier) {
    Box(
        modifier
            .background(color, RoundedCornerShape(6.dp))
            .padding(horizontal = 7.dp, vertical = 2.dp)
    ) {
        Txt(text, size = 11, weight = FontWeight.Bold, color = Color.White)
    }
}

/** Puntuacion, ano, estado y generos de una ficha. */
@Composable
fun MetaChips(a: Anime) {
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
        if (a.rating > 0) {
            Txt("★ ${"%.1f".format(a.rating)}", size = 14, weight = FontWeight.Bold, color = Color(0xFFFFC94D))
        }
        if (a.year > 0) Txt(a.year.toString(), size = 14, color = Brand.muted)
        if (a.status.isNotEmpty()) {
            val c = if (a.status.contains("emisi", ignoreCase = true)) Brand.accent else Color(0xFF3A2A7A)
            Badge(a.status, color = c)
        }
        val g = a.genres.take(3).joinToString(" · ")
        if (g.isNotEmpty()) Txt(g, size = 14, color = Brand.muted, maxLines = 1)
    }
}

/** Poster del anime: en "Ultimos episodios" llega un fotograma y se reemplaza por la portada real. */
@Composable
fun rememberPoster(item: Media): String {
    var url by remember(item.animeSlug, item.cover) { mutableStateOf(item.cover) }
    LaunchedEffect(item.animeSlug) {
        if (item.number > 0 && item.type != "poster" && item.animeSlug.isNotEmpty()) {
            Repo.poster(item.animeSlug)?.let { url = it }
        }
    }
    return url
}

/**
 * En el celular (pantalla estrecha, menos de 600 dp de ancho) la app usa
 * márgenes y navegación de móvil; en la TV todo queda como siempre.
 */
@Composable
fun compactWidth(): Boolean = LocalConfiguration.current.screenWidthDp < 600

@Composable
fun sideStart(): Dp = if (compactWidth()) 16.dp else 48.dp

@Composable
fun sideEnd(): Dp = if (compactWidth()) 16.dp else 84.dp

@Composable
fun PosterCard(
    item: Media,
    onOpen: (Media) -> Unit,
    onFocused: (Media) -> Unit = {},
    focusRequester: FocusRequester? = null
) {
    val poster = rememberPoster(item)
    Column(Modifier.width(140.dp)) {
        FocusSurface(
            onClick = { onOpen(item) },
            onFocused = { onFocused(item) },
            focusRequester = focusRequester,
            modifier = Modifier.fillMaxWidth().aspectRatio(2f / 3f)
        ) { _ ->
            Box(Modifier.fillMaxSize().background(Brand.surface))
            AsyncImage(
                model = poster,
                contentDescription = item.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                Modifier.fillMaxSize()
                    .background(Brush.verticalGradient(0.6f to Color.Transparent, 1f to Color(0xCC000000)))
            )
            if (item.number > 0) {
                Badge("EP ${item.number}", modifier = Modifier.align(Alignment.TopStart).padding(8.dp))
            }
        }
        Txt(
            item.title,
            size = 13,
            maxLines = 2,
            modifier = Modifier.padding(top = 8.dp, start = 2.dp, end = 2.dp)
        )
    }
}

@Composable
fun SectionRow(
    label: String,
    list: List<Media>,
    onOpen: (Media) -> Unit,
    onFocused: (Media) -> Unit = {},
    firstFocus: FocusRequester? = null
) {
    Column(Modifier.padding(bottom = 4.dp)) {
        Row(Modifier.padding(horizontal = 32.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(4.dp).height(18.dp).background(Brand.cyan, RoundedCornerShape(2.dp)))
            Spacer(Modifier.width(10.dp))
            Txt(label, size = 18, weight = FontWeight.Bold)
        }
        LazyRow(
            contentPadding = PaddingValues(horizontal = 32.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            itemsIndexed(list) { i, item ->
                PosterCard(item, onOpen, onFocused, if (i == 0) firstFocus else null)
            }
        }
    }
}
