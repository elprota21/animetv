package com.animetv.app.data

interface S {
    val search: String
    val settings: String
    val back: String
    val onAir: String
    val latest: String
    val episodes: String
    val episode: String
    val loading: String
    val noServers: String
    val noResults: String
    val searchHint: String
    val language: String
    val spanish: String
    val english: String
    val about: String
    val aboutText: String
    val speed: String
    val retry: String
    val loadError: String
    val servers: String
    val resolving: String
    val openWeb: String
    val playHint: String
    val play: String
    val resume: String
    val apiServer: String
    val tagline: String
    val catalog: String
    val catalogHint: String
    val audio: String
    val subbed: String
    val dubbed: String
    val trying: String
    val nextServer: String
    val nextEpisode: String
    val prevEpisode: String
    val top10: String
    val categories: String
    val myList: String
    val like: String
    val liked: String
    val addList: String
    val inList: String
    val kids: String
    val comingNext: String
    val random: String
    val watchNow: String
    val cursorHint: String
    val home: String
    val quality: String
    val auto: String
    val off: String
    val subtitles: String
    val audioTrack: String
    val seasons: String
    val season: String
    val continueWatching: String
    val menu: String
    val menuHint: String
}

object Es : S {
    override val search = "Buscar"
    override val settings = "Ajustes"
    override val back = "Atrás"
    override val onAir = "En emisión"
    override val latest = "Últimos episodios"
    override val episodes = "Episodios"
    override val episode = "Episodio"
    override val loading = "Cargando..."
    override val noServers = "No hay servidores disponibles"
    override val noResults = "Sin resultados"
    override val searchHint = "Escribe un título y pulsa OK"
    override val language = "Idioma"
    override val spanish = "Español"
    override val english = "Inglés"
    override val about = "Acerca de"
    override val aboutText = "AnimeTV 1.0 · Hecho para Android TV"
    override val speed = "Velocidad"
    override val retry = "Reintentar"
    override val loadError = "No se pudo cargar el contenido"
    override val servers = "Elige un servidor"
    override val resolving = "Buscando la mejor fuente de video..."
    override val openWeb = "Abrir reproductor web"
    override val playHint = "◀ ▶ saltar 10 s   ·   OK pausa   ·   ▼ menú"
    override val play = "Reproducir"
    override val resume = "Continuar"
    override val apiServer = "Servidor de datos"
    override val tagline = "Tu anime, en la pantalla grande"
    override val catalog = "Catálogo"
    override val catalogHint = "Elige una letra para explorar todo el catálogo"
    override val audio = "Audio preferido"
    override val subbed = "Subtitulado (SUB)"
    override val dubbed = "Doblado (DUB)"
    override val trying = "Probando"
    override val nextServer = "Siguiente servidor ▶"
    override val nextEpisode = "Capítulo siguiente ⏭"
    override val prevEpisode = "⏮ Capítulo anterior"
    override val top10 = "Top 10 del momento"
    override val categories = "Categorías"
    override val myList = "Mi lista"
    override val like = "Me gusta"
    override val liked = "Te gusta"
    override val addList = "+ Mi lista"
    override val inList = "✓ En mi lista"
    override val kids = "Kids"
    override val comingNext = "Próximos capítulos"
    override val random = "Aleatorio"
    override val watchNow = "Ver ahora"
    override val cursorHint = "Flechas: mover el cursor   ·   OK: clic   ·   ⏩/⏪: saltar 10 s   ·   Atrás: salir"
    override val home = "Inicio"
    override val quality = "Calidad"
    override val auto = "Automática"
    override val off = "Desactivados"
    override val subtitles = "Subtítulos"
    override val audioTrack = "Pista de audio"
    override val seasons = "Temporadas"
    override val season = "Temp."
    override val continueWatching = "Continuar viendo"
    override val menu = "Menú del reproductor"
    override val menuHint = "▲▼ elegir  ·  ◀▶ cambiar  ·  OK aplicar  ·  Atrás cerrar"
}

object En : S {
    override val search = "Search"
    override val settings = "Settings"
    override val back = "Back"
    override val onAir = "On air"
    override val latest = "Latest episodes"
    override val episodes = "Episodes"
    override val episode = "Episode"
    override val loading = "Loading..."
    override val noServers = "No servers available"
    override val noResults = "No results"
    override val searchHint = "Type a title and press OK"
    override val language = "Language"
    override val spanish = "Spanish"
    override val english = "English"
    override val about = "About"
    override val aboutText = "AnimeTV 1.0 · Made for Android TV"
    override val speed = "Speed"
    override val retry = "Retry"
    override val loadError = "Could not load content"
    override val servers = "Pick a server"
    override val resolving = "Finding the best video source..."
    override val openWeb = "Open web player"
    override val playHint = "◀ ▶ skip 10 s   ·   OK pause   ·   ▼ menu"
    override val play = "Play"
    override val resume = "Resume"
    override val apiServer = "Data server"
    override val tagline = "Your anime, on the big screen"
    override val catalog = "Catalog"
    override val catalogHint = "Pick a letter to browse the whole catalog"
    override val audio = "Preferred audio"
    override val subbed = "Subtitled (SUB)"
    override val dubbed = "Dubbed (DUB)"
    override val trying = "Trying"
    override val nextServer = "Next server ▶"
    override val nextEpisode = "Next episode ⏭"
    override val prevEpisode = "⏮ Previous episode"
    override val top10 = "Top 10 right now"
    override val categories = "Categories"
    override val myList = "My List"
    override val like = "Like"
    override val liked = "Liked"
    override val addList = "+ My List"
    override val inList = "✓ In my list"
    override val kids = "Kids"
    override val comingNext = "Upcoming episodes"
    override val random = "Random"
    override val watchNow = "Watch now"
    override val cursorHint = "Arrows: move cursor   ·   OK: click   ·   ⏩/⏪: skip 10 s   ·   Back: exit"
    override val home = "Home"
    override val quality = "Quality"
    override val auto = "Auto"
    override val off = "Off"
    override val subtitles = "Subtitles"
    override val audioTrack = "Audio track"
    override val seasons = "Seasons"
    override val season = "Season"
    override val continueWatching = "Continue watching"
    override val menu = "Player menu"
    override val menuHint = "▲▼ choose  ·  ◀▶ change  ·  OK apply  ·  Back close"
}
