package com.animetv.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.animetv.app.data.Brand
import com.animetv.app.data.S
import kotlinx.coroutines.delay

@Composable
fun SettingsScreen(
    s: S,
    lang: String,
    onChangeLang: (String) -> Unit,
    audio: String,
    onChangeAudio: (String) -> Unit
) {
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(250)
        runCatching { first.requestFocus() }
    }

    Column(Modifier.fillMaxSize().padding(start = if (compactWidth()) 16.dp else 32.dp, end = sideEnd(), top = 26.dp, bottom = 28.dp)) {
        Txt(s.settings, size = 28, weight = FontWeight.Bold)

        Spacer(Modifier.height(24.dp))
        Txt(s.language, size = 18, weight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Chip(s.spanish, lang == "es", first) { onChangeLang("es") }
            Chip(s.english, lang == "en", null) { onChangeLang("en") }
        }

        Spacer(Modifier.height(24.dp))
        Txt(s.audio, size = 18, weight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Chip(s.subbed, audio == "SUB", null) { onChangeAudio("SUB") }
            Chip(s.dubbed, audio == "DUB", null) { onChangeAudio("DUB") }
        }

        Spacer(Modifier.height(28.dp))
        Txt(s.about, size = 18, weight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Txt(s.aboutText, size = 14, color = Brand.muted)

        Spacer(Modifier.height(20.dp))
        Txt(s.apiServer, size = 14, weight = FontWeight.SemiBold)
        Txt(Brand.apiBase, size = 13, color = Brand.muted)
    }
}

@Composable
private fun Chip(label: String, selected: Boolean, requester: FocusRequester?, onClick: () -> Unit) {
    FocusSurface(
        onClick = onClick,
        shape = RoundedCornerShape(50),
        focusScale = 1.05f,
        focusRequester = requester
    ) { focused ->
        Box(
            Modifier.background(if (focused || selected) Brand.accent else Brand.surface)
                .padding(horizontal = 24.dp, vertical = 12.dp)
        ) {
            Txt(label + if (selected) "  ✓" else "", size = 16, weight = FontWeight.SemiBold)
        }
    }
}
