package com.animetv.app.ui

import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.animetv.app.data.AdBlock
import com.animetv.app.data.Brand
import com.animetv.app.data.S
import kotlinx.coroutines.delay
import java.util.concurrent.atomic.AtomicBoolean

private const val DESKTOP_UA =
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

private val NOT_VIDEO = listOf("thumb", "preview", "sprite", "/ads/", "analytics")

private fun looksLikeStream(u: String): Boolean {
    val l = u.lowercase()
    if (NOT_VIDEO.any { l.contains(it) } || AdBlock.isBlocked(l)) return false
    return l.contains(".m3u8") || l.contains(".mp4")
}

private const val HOOK_JS = """
(function(){
  if(window.__ntv) return; window.__ntv = 1;
  function send(u){
    try { if(/\.m3u8|\.mp4/.test(u)) window.NTV.found(String(u), document.location.href); } catch(e){}
  }
  var o = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function(m,u){ send(u); return o.apply(this, arguments); };
  var f = window.fetch;
  if (f) { window.fetch = function(i){
    try { send(typeof i === 'string' ? i : i.url); } catch(e){}
    return f.apply(this, arguments);
  }; }
})();
"""

/**
 * Carga la página del servidor en un WebView A PANTALLA COMPLETA (detrás del
 * aviso de "probando servidor") y captura la URL real del video.
 * Antes el WebView era de 1 dp: muchos servidores detectan que su reproductor
 * "no se ve" y nunca llegan a pedir el video, así que nada cargaba.
 * Al encontrar el video, también se recogen las cookies de la página para
 * pasárselas al reproductor (algunos CDN las exigen y sin ellas dan error).
 */
@Composable
fun ResolverScreen(
    s: S,
    embedUrl: String,
    status: String,
    timeoutMs: Long,
    onFound: (url: String, referer: String, cookie: String) -> Unit,
    onFail: () -> Unit,
    onOpenWeb: () -> Unit,
    onBack: () -> Unit
) {
    val done = remember { AtomicBoolean(false) }
    var wv by remember { mutableStateOf<WebView?>(null) }
    val foundCb by rememberUpdatedState(onFound)
    val failCb by rememberUpdatedState(onFail)
    val webCb by rememberUpdatedState(onOpenWeb)

    DisposableEffect(Unit) {
        onDispose {
            done.set(true)
            wv?.apply { stopLoading(); removeJavascriptInterface("NTV"); destroy() }
        }
    }

    LaunchedEffect(Unit) {
        delay(timeoutMs)
        if (done.compareAndSet(false, true)) failCb()
    }

    Box(Modifier.fillMaxSize()) {
        // 1) La página del servidor, a tamaño completo (queda debajo del aviso).
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { c ->
                val main = Handler(Looper.getMainLooper())
                fun deliver(u: String, ref: String) {
                    val cookie = CookieManager.getInstance().getCookie(u).orEmpty()
                    if (done.compareAndSet(false, true)) main.post { foundCb(u, ref, cookie) }
                }

                WebView(c).apply {
                    isFocusable = false
                    isFocusableInTouchMode = false
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.mediaPlaybackRequiresUserGesture = false
                    settings.javaScriptCanOpenWindowsAutomatically = false
                    settings.userAgentString = DESKTOP_UA

                    addJavascriptInterface(object {
                        @JavascriptInterface
                        fun found(u: String, ref: String) {
                            if (looksLikeStream(u)) deliver(u, ref.ifEmpty { embedUrl })
                        }
                    }, "NTV")

                    webViewClient = object : WebViewClient() {
                        override fun shouldInterceptRequest(
                            view: WebView?,
                            request: WebResourceRequest?
                        ): WebResourceResponse? {
                            val u = request?.url?.toString() ?: return null
                            if (AdBlock.isBlocked(u)) return AdBlock.empty()
                            if (looksLikeStream(u)) {
                                val ref = request?.requestHeaders?.get("Referer").orEmpty().ifEmpty { embedUrl }
                                deliver(u, ref)
                            }
                            return null
                        }

                        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                            view?.evaluateJavascript(AdBlock.NO_POPUP_JS, null)
                            view?.evaluateJavascript(HOOK_JS, null)
                        }

                        override fun onPageFinished(view: WebView?, url: String?) {
                            view?.evaluateJavascript(HOOK_JS, null)
                            view?.evaluateJavascript(AdBlock.AUTOPLAY_JS, null)
                        }
                    }
                    wv = this
                    loadUrl(embedUrl)
                }
            }
        )

        // 2) El aviso, encima: se lee igual que antes y la página ni se entera.
        Box(
            Modifier.fillMaxSize().background(Brand.bg.copy(alpha = 0.94f)),
            contentAlignment = Alignment.Center
        ) {
            Column(
                Modifier.padding(if (compactWidth()) 20.dp else 48.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spinner(Modifier.size(52.dp))
                Spacer(Modifier.height(20.dp))
                Txt(status, size = 18, weight = FontWeight.SemiBold, align = TextAlign.Center)
                Spacer(Modifier.height(6.dp))
                Txt(s.resolving, size = 13, color = Brand.muted, align = TextAlign.Center)
                Spacer(Modifier.height(20.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    TvButton(s.openWeb, { if (done.compareAndSet(false, true)) webCb() })
                    TvButton(s.back, onBack)
                }
            }
        }
    }
}
