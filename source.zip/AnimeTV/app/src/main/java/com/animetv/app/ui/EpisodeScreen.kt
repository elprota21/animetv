package com.animetv.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.animetv.app.data.Brand
import com.animetv.app.data.Embed
import com.animetv.app.data.Repo
import com.animetv.app.data.S
import kotlinx.coroutines.delay

@Composable
fun EpisodeScreen(
    s: S,
    animeSlug: String,
    episode: Int,
    title: String,
    onPick: (Embed) -> Unit,
    onBack: () -> Unit,
    onAuto: () -> Unit = {}
) {
    var list by remember { mutableStateOf<List<Embed>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var attempt by remember { mutableIntStateOf(0) }
    val firstFocus = remember { FocusRequester() }

    LaunchedEffect(animeSlug, episode, attempt) {
        loading = true
        error = null
        val r = runCatching { Repo.embeds(animeSlug, episode) }
        list = r.getOrDefault(emptyList())
        error = r.exceptionOrNull()?.message
        loading = false
    }

    LaunchedEffect(loading, list) {
        if (!loading && list.isNotEmpty()) {
            delay(250)
            runCatching { firstFocus.requestFocus() }
        }
    }

    Column(Modifier.fillMaxSize().padding(start = 48.dp, end = 84.dp, top = 28.dp, bottom = 28.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Txt(title, size = 26, weight = FontWeight.Bold, maxLines = 1)
                Txt("${s.episode} $episode", size = 16, color = Brand.accent, weight = FontWeight.SemiBold)
            }
        }

        Spacer(Modifier.height(20.dp))

        when {
            loading -> Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) { Spinner() }

            list.isEmpty() -> Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                Txt(s.noServers, size = 20, weight = FontWeight.Bold)
                if (error != null) Txt(error ?: "", size = 13, color = Brand.muted)
                Spacer(Modifier.height(16.dp))
                TvButton(s.retry, { attempt++ }, primary = true)
            }

            else -> {
                Txt(s.servers, size = 16, color = Brand.muted)
                Spacer(Modifier.height(10.dp))
                FocusSurface(
                    onClick = { onAuto() },
                    modifier = Modifier.fillMaxWidth(0.6f).height(54.dp),
                    shape = RoundedCornerShape(12.dp),
                    focusScale = 1.03f
                ) { focused ->
                    Row(
                        Modifier.fillMaxSize()
                            .background(if (focused) Brand.accent else Brand.surface)
                            .padding(horizontal = 18.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Txt("▶ ${s.auto}", size = 18, weight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        Badge("AUTO", color = if (focused) Brand.bg else Brand.teal)
                    }
                }
                Spacer(Modifier.height(10.dp))
                LazyColumn(
                    Modifier.fillMaxWidth(0.6f).weight(1f),
                    contentPadding = PaddingValues(vertical = 6.dp, horizontal = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    itemsIndexed(list) { i, e ->
                        FocusSurface(
                            onClick = { onPick(e) },
                            modifier = Modifier.fillMaxWidth().height(54.dp),
                            shape = RoundedCornerShape(12.dp),
                            focusScale = 1.03f,
                            focusRequester = if (i == 0) firstFocus else null
                        ) { focused ->
                            Row(
                                Modifier.fillMaxSize()
                                    .background(if (focused) Brand.accent else Brand.surface)
                                    .padding(horizontal = 18.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Txt(e.name, size = 18, weight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                Badge(
                                    e.lang,
                                    color = if (e.lang == "DUB") Brand.teal else if (focused) Brand.bg else Brand.accent
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
