package com.animetv.app.ui

import android.view.ViewGroup
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.animetv.app.data.AdItem
import com.animetv.app.data.Brand
import com.animetv.app.data.Remote
import com.animetv.app.data.S
import kotlinx.coroutines.delay

/**
 * La «pantallita» de anuncios propios: rota los anuncios de config.json
 * (imagen o video) y los videos SIEMPRE suenan en mute, para no molestar.
 * Si no hay anuncios configurados, no ocupa sitio.
 */
@Composable
fun AdBox(s: S, modifier: Modifier = Modifier) {
    val ads = Remote.ads
    if (ads.isEmpty()) return

    var idx by remember { mutableIntStateOf(0) }
    val ad = ads[idx % ads.size]

    LaunchedEffect(ad, ads) {
        delay(ad.seconds.coerceIn(4, 90) * 1000L)
        if (ads.size > 1) idx = (idx + 1) % ads.size
    }

    Box(modifier.clip(RoundedCornerShape(10.dp)).background(Brand.surface)) {
        if (ad.type == "video") {
            val ctx = LocalContext.current
            val player = remember(ad.url) {
                ExoPlayer.Builder(ctx).build().apply {
                    setMediaItem(MediaItem.fromUri(ad.url))
                    volume = 0f
                    repeatMode = Player.REPEAT_MODE_ALL
                    playWhenReady = true
                    prepare()
                }
            }
            DisposableEffect(player) { onDispose { player.release() } }
            AndroidView(
                factory = { c ->
                    PlayerView(c).apply {
                        this.player = player
                        useController = false
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        } else {
            AsyncImage(
                model = ad.url,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }

        Box(
            Modifier.padding(6.dp)
                .background(Color(0xAA000000), RoundedCornerShape(4.dp))
                .padding(horizontal = 5.dp, vertical = 2.dp)
        ) {
            Txt(s.adLabel, size = 9, color = Color.White)
        }
    }
}

/**
 * Casilla de anuncio dentro del catálogo: ocupa el sitio de un póster más,
 * con la misma forma que un anime, sin robar el foco ni molestar al buscar.
 */
@Composable
fun AdPosterTile(s: S, ad: AdItem, modifier: Modifier = Modifier) {
    Column(modifier.width(140.dp)) {
        Box(
            Modifier.fillMaxWidth().aspectRatio(2f / 3f)
                .clip(RoundedCornerShape(10.dp)).background(Brand.surface)
        ) {
            AsyncImage(
                model = ad.url,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                Modifier.padding(8.dp)
                    .background(Color(0xAA000000), RoundedCornerShape(4.dp))
                    .padding(horizontal = 5.dp, vertical = 2.dp)
            ) {
                Txt(s.adLabel, size = 9, color = Color.White)
            }
        }
        Txt(
            ad.text.ifBlank { s.adLabel },
            size = 13,
            color = Brand.muted,
            maxLines = 2,
            modifier = Modifier.padding(top = 8.dp, start = 2.dp, end = 2.dp)
        )
    }
}
