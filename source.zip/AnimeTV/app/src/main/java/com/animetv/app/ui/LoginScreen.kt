package com.animetv.app.ui

import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.animetv.app.data.Account
import com.animetv.app.data.Brand
import com.animetv.app.data.S
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Acceso obligatorio: correo y contraseña. Sin sesión no se entra a la app.
 * Los campos son EditText clásicos (AndroidView) porque en Android TV el
 * teclado del sistema solo aparece de forma fiable con vistas clásicas;
 * con BasicTextField de Compose el teclado no llegaba a abrirse.
 */
@Composable
fun LoginScreen(s: S, onDone: () -> Unit) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val firstFocus = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        delay(350)
        runCatching { firstFocus.requestFocus() }
    }

    fun submit(signup: Boolean) {
        if (busy) return
        val e = email.trim()
        if (e.isEmpty() || password.length < 6) {
            error = s.loginFailed
            return
        }
        busy = true
        error = null
        scope.launch {
            val r = if (signup) Account.signUp(e, password) else Account.signIn(e, password)
            busy = false
            if (r == null) onDone() else error = r
        }
    }

    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Brand.bg2, Brand.bg))),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.width(460.dp)
        ) {
            Logo(size = 92.dp)
            Spacer(Modifier.height(14.dp))
            Txt(Brand.appName, size = 34, weight = FontWeight.Bold)
            Txt(s.tagline, size = 15, color = Brand.muted)
            Spacer(Modifier.height(26.dp))

            TvField(
                value = email,
                onChange = { email = it },
                hint = s.email,
                password = false,
                focusRequester = firstFocus
            )
            Spacer(Modifier.height(12.dp))
            TvField(
                value = password,
                onChange = { password = it },
                hint = s.password,
                password = true
            )

            val err = error
            if (err != null) {
                Spacer(Modifier.height(12.dp))
                Txt(err, size = 14, color = Color(0xFFFF8A8A), align = TextAlign.Center)
            }

            Spacer(Modifier.height(20.dp))
            if (busy) {
                Spinner()
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    TvButton(s.signIn, { submit(false) }, primary = true)
                    TvButton(s.createAccount, { submit(true) })
                }
            }
        }
    }
}

/** Campo de texto clásico: al enfocarlo y pulsar OK se abre el teclado de la TV. */
@Composable
private fun TvField(
    value: String,
    onChange: (String) -> Unit,
    hint: String,
    password: Boolean,
    focusRequester: FocusRequester? = null
) {
    val textColor = Brand.text.toArgb()
    val hintColor = Brand.muted.toArgb()
    val surface = Brand.surface.toArgb()
    val cyan = Brand.cyan.toArgb()
    val borderOff = Color(0x33FFFFFF).toArgb()

    AndroidView(
        factory = { c ->
            EditText(c).apply {
                setTextColor(textColor)
                setHintTextColor(hintColor)
                textSize = 17f
                setHint(hint)
                isSingleLine = true
                gravity = Gravity.CENTER_VERTICAL
                inputType = if (password)
                    InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                else
                    InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
                imeOptions = EditorInfo.IME_ACTION_NEXT
                setPadding(42, 0, 42, 0)
                val bg = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 30f
                    setColor(surface)
                    setStroke(2, borderOff)
                }
                background = bg
                setOnFocusChangeListener { _, hasFocus ->
                    bg.setStroke(if (hasFocus) 5 else 2, if (hasFocus) cyan else borderOff)
                    if (hasFocus) post {
                        val imm = context.getSystemService(android.content.Context.INPUT_METHOD_SERVICE)
                            as android.view.inputmethod.InputMethodManager
                        imm.showSoftInput(this, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
                    }
                }
                addTextChangedListener(object : TextWatcher {
                    override fun afterTextChanged(e: Editable?) {
                        onChange(e?.toString() ?: "")
                    }
                    override fun beforeTextChanged(t: CharSequence?, a: Int, b: Int, n: Int) {}
                    override fun onTextChanged(t: CharSequence?, a: Int, b: Int, n: Int) {}
                })
                if (value.isNotEmpty()) setText(value)
            }
        },
        update = { et ->
            val cur = et.text?.toString() ?: ""
            if (cur != value) {
                et.setText(value)
                et.setSelection(et.length())
            }
        },
        modifier = Modifier.fillMaxWidth().height(56.dp)
            .then(if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier)
    )
}
