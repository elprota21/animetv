package com.animetv.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import com.animetv.app.data.Brand
import com.animetv.app.data.Prefs
import com.animetv.app.data.S
import kotlinx.coroutines.delay
import java.util.Locale

private const val UA =
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

private val SPEEDS = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f)

private fun originOf(u: String): String =
    runCatching { java.net.URI(u).let { "${it.scheme}://${it.host}" } }.getOrDefault("")

private fun fmt(ms: Long): String {
    val t = (ms / 1000).coerceAtLeast(0)
    val h = t / 3600
    val m = (t % 3600) / 60
    val sec = t % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
}

private fun langName(code: String): String =
    Locale(code).displayLanguage.replaceFirstChar { it.uppercase() }.ifEmpty { code }

private fun wrap(i: Int, n: Int): Int = ((i % n) + n) % n

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    s: S,
    url: String,
    referer: String,
    title: String,
    resumeKey: String,
    prefs: Prefs,
    onStarted: () -> Unit,
    onNextServer: (() -> Unit)?,
    onPrevEpisode: (() -> Unit)? = null,
    onNextEpisode: (() -> Unit)? = null,
    onError: () -> Unit,
    onExit: () -> Unit
) {
    val ctx = LocalContext.current
    val focus = remember { FocusRequester() }
    var speed by remember { mutableFloatStateOf(1f) }
    var playing by remember { mutableStateOf(true) }
    var buffering by remember { mutableStateOf(true) }
    var posMs by remember { mutableLongStateOf(0L) }
    var durMs by remember { mutableLongStateOf(0L) }
    var overlay by remember { mutableStateOf(true) }
    var lastTouch by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var started by remember { mutableStateOf(false) }
    var reported by remember { mutableStateOf(false) }
    var advanced by remember { mutableStateOf(false) }

    // Menu del reproductor
    var menuOpen by remember { mutableStateOf(false) }
    var menuIdx by remember { mutableIntStateOf(0) }
    var heights by remember { mutableStateOf<List<Int>>(emptyList()) }
    var textLangs by remember { mutableStateOf<List<String>>(emptyList()) }
    var audioLangs by remember { mutableStateOf<List<String>>(emptyList()) }
    var qSel by remember { mutableIntStateOf(-1) }   // -1 = automatica
    var subSel by remember { mutableIntStateOf(-1) } // -1 = desactivados
    var audSel by remember { mutableIntStateOf(0) }

    val fail: () -> Unit = {
        if (!reported) {
            reported = true
            onError()
        }
    }

    val exo = remember {
        val props = buildMap<String, String> {
            if (referer.isNotEmpty()) put("Referer", referer)
            val o = originOf(referer)
            if (o.isNotEmpty()) put("Origin", o)
        }
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(UA)
            .setAllowCrossProtocolRedirects(true)
            .setDefaultRequestProperties(props)

        ExoPlayer.Builder(ctx)
            .setMediaSourceFactory(DefaultMediaSourceFactory(http))
            .build()
            .apply {
                val b = MediaItem.Builder().setUri(url)
                if (url.contains(".m3u8", ignoreCase = true)) b.setMimeType(MimeTypes.APPLICATION_M3U8)
                setMediaItem(b.build())
                prepare()
                val p = prefs.position(resumeKey)
                if (p > 0) seekTo(p)
                playWhenReady = true
            }
    }

    DisposableEffect(exo) {
        val l = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) { fail() }

            override fun onPlaybackStateChanged(state: Int) {
                buffering = state == Player.STATE_BUFFERING
                if (state == Player.STATE_READY && !started) {
                    started = true
                    onStarted()
                }
                // Al terminar el capitulo, pasa solo al siguiente (si hay).
                if (state == Player.STATE_ENDED && !advanced) {
                    advanced = true
                    onNextEpisode?.invoke()
                }
            }

            override fun onTracksChanged(tracks: Tracks) {
                val hs = sortedSetOf<Int>()
                val tl = mutableListOf<String>()
                val al = mutableListOf<String>()
                for (g in tracks.groups) {
                    for (i in 0 until g.length) {
                        val f = g.getTrackFormat(i)
                        val lang = f.language.orEmpty()
                        when (g.type) {
                            C.TRACK_TYPE_VIDEO -> if (f.height > 0) hs.add(f.height)
                            C.TRACK_TYPE_TEXT -> if (lang.isNotEmpty() && lang != "und" && lang !in tl) tl.add(lang)
                            C.TRACK_TYPE_AUDIO -> if (lang.isNotEmpty() && lang != "und" && lang !in al) al.add(lang)
                        }
                    }
                }
                heights = hs.toList().sortedDescending()
                textLangs = tl
                audioLangs = al
            }
        }
        exo.addListener(l)
        onDispose {
            exo.removeListener(l)
            val p = exo.currentPosition
            val d = exo.duration
            prefs.savePosition(resumeKey, if (d > 0 && p > d - 30_000) 0L else p)
            exo.release()
        }
    }

    LaunchedEffect(exo) {
        var tick = 0
        while (true) {
            posMs = exo.currentPosition
            durMs = exo.duration.takeIf { it > 0 } ?: 0L
            playing = exo.playWhenReady
            if (overlay && playing && !menuOpen && System.currentTimeMillis() - lastTouch > 4000) overlay = false
            tick++
            if (tick % 10 == 0 && posMs > 0) prefs.savePosition(resumeKey, posMs)
            delay(500)
        }
    }

    // Si en 15 s no arranca, se considera fallido y se pasa al siguiente servidor.
    LaunchedEffect(Unit) {
        delay(15_000)
        if (!started) fail()
    }

    BackHandler { if (menuOpen) menuOpen = false else onExit() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    fun poke() {
        lastTouch = System.currentTimeMillis()
        overlay = true
    }

    fun seekBy(delta: Long) {
        exo.seekTo((exo.currentPosition + delta).coerceAtLeast(0))
        poke()
    }

    // ---- filas del menu ----
    val rowKeys = buildList {
        add("quality")
        add("speed")
        if (textLangs.isNotEmpty()) add("subs")
        if (audioLangs.size > 1) add("audio")
        if (onPrevEpisode != null) add("epPrev")
        if (onNextEpisode != null) add("epNext")
        if (onNextServer != null) add("server")
    }
    val actionKeys = setOf("server", "epPrev", "epNext")

    fun runAction(k: String) {
        when (k) {
            "server" -> onNextServer?.invoke()
            "epPrev" -> onPrevEpisode?.invoke()
            "epNext" -> onNextEpisode?.invoke()
        }
    }

    fun rowLabel(k: String): String = when (k) {
        "quality" -> s.quality
        "speed" -> s.speed
        "subs" -> s.subtitles
        "audio" -> s.audioTrack
        "epPrev" -> s.prevEpisode
        "epNext" -> s.nextEpisode
        else -> s.nextServer
    }

    fun rowValue(k: String): String = when (k) {
        "quality" -> if (qSel < 0 || qSel >= heights.size) s.auto else "${heights[qSel]}p"
        "speed" -> "${speed}x"
        "subs" -> if (subSel < 0 || subSel >= textLangs.size) s.off else langName(textLangs[subSel])
        "audio" -> audioLangs.getOrNull(audSel)?.let { langName(it) } ?: ""
        else -> ""
    }

    fun step(k: String, d: Int) {
        val params = exo.trackSelectionParameters.buildUpon()
        when (k) {
            "quality" -> {
                val n = heights.size + 1
                qSel = wrap(qSel + 1 + d, n) - 1
                if (qSel < 0) params.clearVideoSizeConstraints()
                else params.setMaxVideoSize(Int.MAX_VALUE, heights[qSel])
                exo.trackSelectionParameters = params.build()
            }
            "speed" -> {
                val i = SPEEDS.indexOf(speed).let { if (it < 0) 2 else it }
                speed = SPEEDS[wrap(i + d, SPEEDS.size)]
                exo.setPlaybackSpeed(speed)
            }
            "subs" -> {
                val n = textLangs.size + 1
                subSel = wrap(subSel + 1 + d, n) - 1
                if (subSel < 0) {
                    params.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                } else {
                    params.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                    params.setPreferredTextLanguage(textLangs[subSel])
                }
                exo.trackSelectionParameters = params.build()
            }
            "audio" -> {
                if (audioLangs.isNotEmpty()) {
                    audSel = wrap(audSel + d, audioLangs.size)
                    params.setPreferredAudioLanguage(audioLangs[audSel])
                    exo.trackSelectionParameters = params.build()
                }
            }
        }
        poke()
    }

    Box(
        Modifier.fillMaxSize()
            .background(Color.Black)
            .focusRequester(focus)
            .focusable()
            .onPreviewKeyEvent { ev ->
                if (ev.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false

                if (menuOpen) {
                    val k = rowKeys.getOrNull(menuIdx)
                    return@onPreviewKeyEvent when (ev.key) {
                        Key.DirectionUp -> { menuIdx = (menuIdx - 1).coerceAtLeast(0); true }
                        Key.DirectionDown -> { menuIdx = (menuIdx + 1).coerceAtMost(rowKeys.size - 1); true }
                        Key.DirectionLeft -> { if (k != null && k !in actionKeys) step(k, -1); true }
                        Key.DirectionRight -> { if (k != null && k !in actionKeys) step(k, 1); true }
                        Key.DirectionCenter, Key.Enter, Key.NumPadEnter -> {
                            if (k != null && k in actionKeys) {
                                menuOpen = false
                                runAction(k)
                            } else if (k != null) {
                                step(k, 1)
                            }
                            true
                        }
                        Key.Menu -> { menuOpen = false; true }
                        else -> false
                    }
                }

                when (ev.key) {
                    Key.DirectionCenter, Key.Enter, Key.NumPadEnter, Key.MediaPlayPause, Key.Spacebar -> {
                        exo.playWhenReady = !exo.playWhenReady
                        playing = exo.playWhenReady
                        poke(); true
                    }
                    Key.MediaPlay -> { exo.playWhenReady = true; poke(); true }
                    Key.MediaPause -> { exo.playWhenReady = false; poke(); true }
                    Key.DirectionRight, Key.MediaFastForward -> { seekBy(10_000); true }
                    Key.DirectionLeft, Key.MediaRewind -> { seekBy(-10_000); true }
                    Key.MediaNext -> { if (onNextEpisode != null) { onNextEpisode.invoke(); true } else false }
                    Key.MediaPrevious -> { if (onPrevEpisode != null) { onPrevEpisode.invoke(); true } else false }
                    Key.DirectionUp -> { poke(); true }
                    Key.DirectionDown, Key.Menu -> { menuOpen = true; menuIdx = 0; poke(); true }
                    else -> false
                }
            }
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { c ->
                PlayerView(c).apply {
                    player = exo
                    useController = false
                    keepScreenOn = true
                    isFocusable = false
                    isFocusableInTouchMode = false
                }
            }
        )

        if (buffering) {
            Spinner(Modifier.align(Alignment.Center).size(56.dp))
        }

        // Tu logo como marca de agua, siempre visible
        Logo(Modifier.align(Alignment.TopEnd).padding(top = 14.dp, end = 20.dp), 38.dp, 0.55f)

        AnimatedVisibility(
            visible = overlay,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(Modifier.fillMaxSize()) {
                Box(
                    Modifier.fillMaxWidth().align(Alignment.TopCenter)
                        .background(Brush.verticalGradient(listOf(Color(0xCC000000), Color.Transparent)))
                        .padding(start = 48.dp, end = 84.dp, top = 24.dp, bottom = 24.dp)
                ) {
                    Txt(title, size = 20, weight = FontWeight.SemiBold, maxLines = 1)
                }

                Column(
                    Modifier.fillMaxWidth().align(Alignment.BottomCenter)
                        .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xDD000000))))
                        .padding(horizontal = 48.dp, vertical = 24.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Txt(if (playing) "II" else "▶", size = 22, weight = FontWeight.Bold)
                        Spacer(Modifier.width(14.dp))
                        Txt("${fmt(posMs)} / ${fmt(durMs)}", size = 15, color = Brand.muted, modifier = Modifier.weight(1f))
                        Badge("${s.speed} ${speed}x")
                    }
                    Spacer(Modifier.height(10.dp))
                    val frac = if (durMs > 0) (posMs.toFloat() / durMs).coerceIn(0f, 1f) else 0f
                    Box(
                        Modifier.fillMaxWidth().height(5.dp)
                            .background(Color(0x40FFFFFF), RoundedCornerShape(3.dp))
                    ) {
                        Box(
                            Modifier.fillMaxWidth(frac).fillMaxHeight()
                                .background(Brand.accent, RoundedCornerShape(3.dp))
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Txt(s.playHint, size = 12, color = Brand.muted)
                }
            }
        }

        // Menu lateral
        AnimatedVisibility(
            visible = menuOpen,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.CenterEnd)
        ) {
            Column(
                Modifier.padding(end = 24.dp).width(320.dp)
                    .background(Color(0xEE140A2E), RoundedCornerShape(18.dp))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Txt(s.menu, size = 18, weight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                rowKeys.forEachIndexed { i, k ->
                    val sel = i == menuIdx
                    Row(
                        Modifier.fillMaxWidth().height(44.dp)
                            .background(if (sel) Brand.accent else Color(0x22FFFFFF), RoundedCornerShape(10.dp))
                            .padding(horizontal = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Txt(rowLabel(k), size = 15, weight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        val v = rowValue(k)
                        if (v.isNotEmpty()) Txt(if (sel) "◀  $v  ▶" else v, size = 14, color = if (sel) Color.White else Brand.muted)
                    }
                }
                Spacer(Modifier.height(4.dp))
                Txt(s.menuHint, size = 11, color = Brand.muted)
            }
        }
    }
}
