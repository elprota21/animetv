package com.animetv.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.animetv.app.data.Brand
import com.animetv.app.data.Embed
import com.animetv.app.data.En
import com.animetv.app.data.Es
import com.animetv.app.data.Media
import com.animetv.app.data.Prefs
import com.animetv.app.data.Repo
import com.animetv.app.data.S
import com.animetv.app.data.hostKey
import com.animetv.app.ui.*

sealed class Screen {
    data object Home : Screen()
    data object Search : Screen()
    data object Catalog : Screen()
    data object Settings : Screen()
    data class Detail(val slug: String) : Screen()

    /** Lista manual de servidores (solo si ninguno funciona solo). */
    data class Episode(val animeSlug: String, val number: Int, val title: String) : Screen()

    /** Carga los servidores del episodio y arranca la cadena automatica. */
    data class Auto(val animeSlug: String, val number: Int, val title: String) : Screen()

    data class Resolve(
        val embeds: List<Embed>,
        val index: Int,
        val animeSlug: String,
        val number: Int,
        val title: String,
        val manual: Boolean
    ) : Screen()

    data class Player(
        val url: String,
        val referer: String,
        val embeds: List<Embed>,
        val index: Int,
        val animeSlug: String,
        val number: Int,
        val title: String,
        val manual: Boolean
    ) : Screen()

    data class WebPlayer(
        val embeds: List<Embed>,
        val index: Int,
        val animeSlug: String,
        val number: Int,
        val title: String
    ) : Screen()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = Prefs(this)

        setContent {
            val stack = remember { mutableStateListOf<Screen>(Screen.Home) }
            var lang by remember { mutableStateOf(prefs.lang) }
            var audio by remember { mutableStateOf(prefs.audio) }
            val s: S = if (lang == "en") En else Es
            val screen = stack.last()

            fun push(x: Screen) { stack.add(x) }
            fun pop() { if (stack.size > 1) stack.removeAt(stack.lastIndex) }
            fun replace(x: Screen) { stack[stack.lastIndex] = x }
            fun openMedia(m: Media) = push(Screen.Detail(m.animeSlug))

            fun goTab(t: Tab) {
                stack.clear()
                stack.add(
                    when (t) {
                        Tab.Home -> Screen.Home
                        Tab.Catalog -> Screen.Catalog
                        Tab.Search -> Screen.Search
                        Tab.Settings -> Screen.Settings
                    }
                )
            }

            // Si un servidor falla pasa al siguiente; si ya no quedan, muestra la lista manual.
            fun nextOrList(embeds: List<Embed>, index: Int, slug: String, n: Int, title: String) {
                val next = index + 1
                if (next < embeds.size) replace(Screen.Resolve(embeds, next, slug, n, title, false))
                else replace(Screen.Episode(slug, n, title))
            }

            // Atras: vuelve a la pantalla anterior; desde otra pestana va a Inicio; en Inicio cierra la app.
            BackHandler(enabled = stack.size > 1 || screen !is Screen.Home) {
                if (stack.size > 1) pop() else stack[0] = Screen.Home
            }

            Box(Modifier.fillMaxSize().background(Brand.bg)) {
                key(screen) {
                    when (val sc = screen) {
                        is Screen.Home -> Shell(s, Tab.Home, { goTab(it) }) {
                            HomeScreen(s, prefs, onOpen = { openMedia(it) })
                        }

                        is Screen.Catalog -> Shell(s, Tab.Catalog, { goTab(it) }) {
                            CatalogScreen(s, onOpen = { openMedia(it) })
                        }

                        is Screen.Search -> Shell(s, Tab.Search, { goTab(it) }) {
                            SearchScreen(s, onOpen = { openMedia(it) })
                        }

                        is Screen.Settings -> Shell(s, Tab.Settings, { goTab(it) }) {
                            SettingsScreen(
                                s, lang,
                                onChangeLang = { lang = it; prefs.lang = it },
                                audio = audio,
                                onChangeAudio = { audio = it; prefs.audio = it }
                            )
                        }

                        is Screen.Detail -> DetailScreen(
                            s, sc.slug, prefs,
                            onEpisode = { title, n -> push(Screen.Auto(sc.slug, n, title)) },
                            onSeason = { slug -> replace(Screen.Detail(slug)) },
                            onBack = { pop() }
                        )

                        is Screen.Auto -> AutoScreen(
                            s, sc.animeSlug, sc.number, sc.title, prefs,
                            onReady = { list ->
                                replace(Screen.Resolve(list, 0, sc.animeSlug, sc.number, sc.title, false))
                            },
                            onBack = { pop() }
                        )

                        is Screen.Episode -> EpisodeScreen(
                            s, sc.animeSlug, sc.number, sc.title,
                            onPick = { e ->
                                push(Screen.Resolve(listOf(e), 0, sc.animeSlug, sc.number, sc.title, true))
                            },
                            onBack = { pop() }
                        )

                        is Screen.Resolve -> {
                            val e = sc.embeds[sc.index]
                            ResolverScreen(
                                s, e.url,
                                status = "${s.trying} ${e.name} (${sc.index + 1}/${sc.embeds.size})",
                                timeoutMs = if (sc.manual) 18_000L else 12_000L,
                                onFound = { url, ref ->
                                    replace(
                                        Screen.Player(
                                            url, ref, sc.embeds, sc.index,
                                            sc.animeSlug, sc.number, sc.title, sc.manual
                                        )
                                    )
                                },
                                onFail = {
                                    if (sc.manual) replace(Screen.WebPlayer(sc.embeds, sc.index, sc.animeSlug, sc.number, sc.title))
                                    else nextOrList(sc.embeds, sc.index, sc.animeSlug, sc.number, sc.title)
                                },
                                onOpenWeb = { replace(Screen.WebPlayer(sc.embeds, sc.index, sc.animeSlug, sc.number, sc.title)) },
                                onBack = { pop() }
                            )
                        }

                        is Screen.Player -> {
                            val e = sc.embeds[sc.index]
                            PlayerScreen(
                                s, sc.url, sc.referer,
                                title = "${sc.title} · ${s.episode} ${sc.number}",
                                resumeKey = "${sc.animeSlug}-${sc.number}",
                                prefs = prefs,
                                onStarted = {
                                    prefs.goodHost = hostKey(e.url)
                                    prefs.addRecent(
                                        Media(
                                            sc.title,
                                            Repo.posterCached(sc.animeSlug) ?: "",
                                            sc.animeSlug, sc.animeSlug, "poster", sc.number
                                        )
                                    )
                                },
                                onNextServer = if (sc.index + 1 < sc.embeds.size) {
                                    {
                                        replace(
                                            Screen.Resolve(sc.embeds, sc.index + 1, sc.animeSlug, sc.number, sc.title, false)
                                        )
                                    }
                                } else null,
                                onError = {
                                    if (sc.manual) replace(Screen.WebPlayer(sc.embeds, sc.index, sc.animeSlug, sc.number, sc.title))
                                    else nextOrList(sc.embeds, sc.index, sc.animeSlug, sc.number, sc.title)
                                },
                                onExit = { pop() }
                            )
                        }

                        is Screen.WebPlayer -> {
                            val next = sc.index + 1
                            WebPlayerScreen(
                                s, sc.embeds[sc.index].url,
                                onNextServer = if (next < sc.embeds.size) {
                                    {
                                        replace(Screen.Resolve(sc.embeds, next, sc.animeSlug, sc.number, sc.title, false))
                                    }
                                } else null,
                                onBack = { pop() }
                            )
                        }
                    }

                    // Tu logo arriba a la derecha en las pantallas sin menu lateral
                    if (screen is Screen.Detail || screen is Screen.Episode ||
                        screen is Screen.Auto || screen is Screen.Resolve
                    ) {
                        Logo(Modifier.align(Alignment.TopEnd).padding(top = 14.dp, end = 20.dp), 44.dp)
                    }
                }
            }
        }
    }
}
