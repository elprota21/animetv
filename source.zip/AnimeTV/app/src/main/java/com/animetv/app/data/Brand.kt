package com.animetv.app.data

import androidx.compose.ui.graphics.Color

object Brand {
    const val appName = "AnimeTV"
    const val appVersion = "1.3.6"

    // Servidor de cuentas y «me gusta» (Supabase). La clave anon es la clave
    // cliente publica; los datos estan protegidos por RLS (cada usuario, lo suyo).
    const val supabaseUrl = "https://voottxamfqrgzahtrjrp.supabase.co"
    const val supabaseAnon = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZvb3R0eGFtZnFyZ3phaHRyanJwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTQyODg5ODYsImV4cCI6MjEwOTg2NDk4Nn0.7HJuef2ObBs4nPzjz-Rhs07ZVR9TDvQyj-ShFAABElw"

    // Correos con panel de administrador dentro de la app.
    val adminEmails = setOf("mm14211338@gmail.com", "ml14211338@gmail.com")

    // Si la API cambia de dominio, es lo unico que hay que tocar.
    const val apiBase = "https://animeav1.ahmedrangel.com/api"

    // Paleta tomada de tu logo: violeta profundo + cian
    val bg = Color(0xFF0D0620)
    val bg2 = Color(0xFF1A0B3D)
    val surface = Color(0xFF1E1245)
    val accent = Color(0xFF8B5CFF)
    val cyan = Color(0xFF3DE0E0)
    val teal = Color(0xFF3DE0E0)
    val text = Color(0xFFF1EDFF)
    val muted = Color(0xFFA79BCB)
}
