package com.animetv.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.animetv.app.data.Account
import com.animetv.app.data.Brand
import com.animetv.app.data.Prefs
import com.animetv.app.data.S
import kotlinx.coroutines.launch

/**
 * Perfil del usuario: su cuenta, sus «me gusta» y cerrar sesión.
 * Si el correo es de Miguel, abajo aparece el panel de administrador
 * con los animes y capítulos más gustados por todos los usuarios.
 */
@Composable
fun ProfileScreen(s: S, prefs: Prefs, onSignOut: () -> Unit) {
    val scope = rememberCoroutineScope()
    val admin = remember { Account.isAdmin() }
    var topA by remember { mutableStateOf<List<Account.TopAnime>>(emptyList()) }
    var topE by remember { mutableStateOf<List<Account.TopEpisode>>(emptyList()) }
    var loadingAdmin by remember { mutableStateOf(false) }
    var loaded by remember { mutableStateOf(false) }
    val myLikes = remember { prefs.likedSlugs().size }

    LaunchedEffect(Unit) {
        if (admin) {
            loadingAdmin = true
            topA = Account.topAnimes()
            topE = Account.topEpisodes()
            loadingAdmin = false
            loaded = true
        }
    }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 32.dp, vertical = 26.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row {
                Txt(s.profile, size = 26, weight = FontWeight.Bold)
                if (admin) {
                    Spacer(Modifier.width(12.dp))
                    Badge(s.admin)
                }
            }
            Spacer(Modifier.height(6.dp))
            Txt(Account.email(), size = 17, color = Brand.muted)
            Spacer(Modifier.height(6.dp))
            Txt("♥ $myLikes · ${s.myList}: ${prefs.savedList().size}", size = 15, color = Brand.muted)
            Spacer(Modifier.height(18.dp))
            TvButton(s.signOut, {
                scope.launch {
                    Account.signOut()
                    onSignOut()
                }
            })
        }

        if (admin) {
            item {
                Spacer(Modifier.height(16.dp))
                Txt("📊 ${s.topLiked}", size = 20, weight = FontWeight.Bold)
                if (loadingAdmin) {
                    Spacer(Modifier.height(8.dp))
                    Txt(s.loading, size = 14, color = Brand.muted)
                } else if (loaded && topA.isEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Txt(s.noLikesYet, size = 14, color = Brand.muted)
                }
            }
            items(topA.size) { i ->
                val t = topA[i]
                Row(Modifier.fillMaxWidth()) {
                    Txt("${i + 1}.", size = 16, weight = FontWeight.Bold, color = Brand.cyan)
                    Spacer(Modifier.width(10.dp))
                    Txt(t.title.ifEmpty { t.slug }, size = 16, modifier = Modifier.weight(1f), maxLines = 1)
                    Txt("♥ ${t.likes}", size = 16, weight = FontWeight.SemiBold)
                }
            }
            item {
                Spacer(Modifier.height(16.dp))
                Txt("📊 ${s.topEpisodes}", size = 20, weight = FontWeight.Bold)
                if (loaded && topE.isEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Txt(s.noLikesYet, size = 14, color = Brand.muted)
                }
            }
            items(topE.size) { i ->
                val t = topE[i]
                Row(Modifier.fillMaxWidth()) {
                    Txt("${i + 1}.", size = 16, weight = FontWeight.Bold, color = Brand.cyan)
                    Spacer(Modifier.width(10.dp))
                    Txt("${t.slug} · ${s.episode} ${t.episode}", size = 16, modifier = Modifier.weight(1f), maxLines = 1)
                    Txt("♥ ${t.likes}", size = 16, weight = FontWeight.SemiBold)
                }
            }
        }
    }
}
