package com.animetv.app.ui

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.animetv.app.data.Anime
import com.animetv.app.data.Brand
import com.animetv.app.data.Media
import com.animetv.app.data.Prefs
import com.animetv.app.data.Repo
import com.animetv.app.data.S
import kotlinx.coroutines.delay

@Composable
fun HomeScreen(s: S, prefs: Prefs, onOpen: (Media) -> Unit, onGenre: (String) -> Unit = {}) {
    var onAir by remember { mutableStateOf<List<Media>>(emptyList()) }
    var latest by remember { mutableStateOf<List<Media>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var attempt by remember { mutableIntStateOf(0) }
    var focused by remember { mutableStateOf<Media?>(null) }
    var detail by remember { mutableStateOf<Anime?>(null) }
    val recent = remember { prefs.recent() }
    val saved = remember { prefs.savedList() }
    val firstFocus = remember { FocusRequester() }

    LaunchedEffect(attempt) {
        loading = true
        error = null
        val a = runCatching { Repo.onAir() }
        val l = runCatching { Repo.latest() }
        onAir = a.getOrDefault(emptyList())
        latest = l.getOrDefault(emptyList())
        if (onAir.isEmpty() && latest.isEmpty()) {
            error = (a.exceptionOrNull() ?: l.exceptionOrNull())?.message ?: "Sin datos"
        }
        if (focused == null) focused = recent.firstOrNull() ?: onAir.firstOrNull() ?: latest.firstOrNull()
        loading = false
    }

    LaunchedEffect(loading, error) {
        if (!loading && error == null) {
            delay(250)
            runCatching { firstFocus.requestFocus() }
        }
    }

    // Ficha del titulo enfocado (sinopsis, puntuacion...), con retardo para no saturar al desplazarse
    LaunchedEffect(focused?.animeSlug) {
        val m = focused ?: return@LaunchedEffect
        detail = null
        delay(350)
        detail = runCatching { Repo.anime(m.animeSlug) }.getOrNull()
    }

    val bgPoster = focused?.let { rememberPoster(it) } ?: ""

    Box(Modifier.fillMaxSize()) {
        // Fondo: portada del titulo enfocado, fundida con el color de fondo
        Box(Modifier.align(Alignment.TopEnd).fillMaxWidth(0.62f).fillMaxHeight(0.72f)) {
            Crossfade(targetState = bgPoster, label = "backdrop") { cover ->
                if (cover.isNotEmpty()) {
                    AsyncImage(
                        model = cover,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        alpha = 0.5f,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
        Box(
            Modifier.fillMaxSize().background(
                Brush.horizontalGradient(0f to Brand.bg2, 0.4f to Brand.bg2, 0.85f to Color.Transparent)
            )
        )
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(0.3f to Color.Transparent, 0.66f to Brand.bg)
            )
        )

        Column(Modifier.fillMaxSize()) {
            // Hero
            Column(
                Modifier.padding(start = if (compactWidth()) 16.dp else 32.dp, top = 26.dp).fillMaxWidth(if (compactWidth()) 0.94f else 0.58f).height(216.dp),
                verticalArrangement = Arrangement.Bottom
            ) {
                val f = focused
                if (f != null) {
                    Txt(f.title, size = 30, weight = FontWeight.Bold, maxLines = 2, lineHeight = 34)
                    Spacer(Modifier.height(8.dp))
                    val d = detail
                    if (d != null && d.slug == f.animeSlug) {
                        MetaChips(d)
                        if (d.synopsis.isNotEmpty()) {
                            Spacer(Modifier.height(8.dp))
                            Txt(d.synopsis, size = 13, maxLines = 2, lineHeight = 18, color = Brand.muted)
                        }
                    } else {
                        val meta = listOfNotNull(
                            f.number.takeIf { it > 0 }?.let { "${s.episode} $it" },
                            f.type.takeIf { it.isNotEmpty() && it != "poster" }
                        ).joinToString("  ·  ")
                        if (meta.isNotEmpty()) Txt(meta, size = 14, color = Brand.muted)
                    }
                } else {
                    Txt(s.tagline, size = 22, color = Brand.muted)
                }
                val hero = focused
                if (hero != null) {
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        TvButton("▶ ${s.watchNow}", { onOpen(hero) }, primary = true)
                        var heroSaved by remember(hero.animeSlug) { mutableStateOf(prefs.isSaved(hero.animeSlug)) }
                        TvButton(
                            if (heroSaved) s.inList else s.addList,
                            { heroSaved = prefs.toggleSaved(hero) }
                        )
                        val pool = latest + onAir
                        if (pool.size > 1) TvButton("🎲 ${s.random}", { onOpen(pool.random()) })
                    }
                }
            }

            when {
                loading -> Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    Spinner()
                }
                error != null -> Column(
                    Modifier.fillMaxWidth().weight(1f).padding(horizontal = if (compactWidth()) 16.dp else 32.dp),
                    verticalArrangement = Arrangement.Center
                ) {
                    Txt(s.loadError, size = 20, weight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Txt(error ?: "", size = 13, color = Brand.muted)
                    Spacer(Modifier.height(16.dp))
                    TvButton(s.retry, { attempt++ }, primary = true, focusRequester = firstFocus)
                }
                else -> {
                    val top10 = (latest + onAir).distinctBy { it.animeSlug }.take(10)
                    val nextUps = onAir.filter { it.number > 0 }.map {
                        Media(it.title, it.cover, it.slug, it.animeSlug, "next", it.number + 1)
                    }
                    val rows = buildList {
                        if (recent.isNotEmpty()) add(Triple(s.continueWatching, "std", recent))
                        if (saved.isNotEmpty()) add(Triple(s.myList, "std", saved))
                        if (top10.size >= 4) add(Triple(s.top10, "top10", top10))
                        if (onAir.isNotEmpty()) add(Triple(s.onAir, "std", onAir))
                        if (nextUps.isNotEmpty()) add(Triple(s.comingNext, "std", nextUps))
                        if (latest.isNotEmpty()) add(Triple(s.latest, "std", latest))
                        add(Triple(s.categories, "cats", emptyList()))
                        Unit
                    }
                    LazyColumn(
                        Modifier.fillMaxWidth().weight(1f),
                        contentPadding = PaddingValues(bottom = 24.dp)
                    ) {
                        itemsIndexed(rows) { i, row ->
                            when (row.second) {
                                "top10" -> TopTenRow(
                                    row.first, row.third, onOpen,
                                    onFocused = { focused = it }
                                )
                                "cats" -> CategoriesRow(row.first, onGenre)
                                else -> SectionRow(
                                    row.first, row.third, onOpen,
                                    onFocused = { focused = it },
                                    firstFocus = if (i == 0) firstFocus else null
                                )
                            }
                        }
                    }
                }
            }
        }

        Txt(
            "v${Brand.appVersion}",
            size = 12,
            color = Brand.muted,
            modifier = Modifier.align(Alignment.BottomEnd).padding(end = 20.dp, bottom = 10.dp)
        )
    }
}

@Composable
private fun TopTenRow(
    label: String,
    list: List<Media>,
    onOpen: (Media) -> Unit,
    onFocused: (Media) -> Unit
) {
    Column(Modifier.padding(bottom = 4.dp)) {
        Row(Modifier.padding(horizontal = if (compactWidth()) 16.dp else 32.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(4.dp).height(18.dp).background(Brand.cyan, RoundedCornerShape(2.dp)))
            Spacer(Modifier.width(10.dp))
            Txt(label, size = 18, weight = FontWeight.Bold)
        }
        LazyRow(
            contentPadding = PaddingValues(horizontal = 32.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            itemsIndexed(list) { i, item ->
                Row(verticalAlignment = Alignment.Bottom) {
                    Txt(
                        "${i + 1}",
                        size = 76,
                        weight = FontWeight.Black,
                        color = Brand.accent.copy(alpha = 0.85f)
                    )
                    PosterCard(item, onOpen, onFocused)
                }
            }
        }
    }
}

private val HOME_GENRES = listOf(
    "Acción", "Aventura", "Comedia", "Drama", "Romance",
    "Fantasía", "Ciencia ficción", "Terror", "Misterio", "Deportes"
)

@Composable
private fun CategoriesRow(label: String, onGenre: (String) -> Unit) {
    Column(Modifier.padding(bottom = 4.dp)) {
        Row(Modifier.padding(horizontal = if (compactWidth()) 16.dp else 32.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(4.dp).height(18.dp).background(Brand.cyan, RoundedCornerShape(2.dp)))
            Spacer(Modifier.width(10.dp))
            Txt(label, size = 18, weight = FontWeight.Bold)
        }
        LazyRow(
            contentPadding = PaddingValues(horizontal = 32.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            itemsIndexed(HOME_GENRES) { _, g ->
                FocusSurface(
                    onClick = { onGenre(g) },
                    modifier = Modifier.height(46.dp),
                    shape = RoundedCornerShape(50),
                    focusScale = 1.06f
                ) { focused ->
                    Box(
                        Modifier.fillMaxHeight()
                            .background(if (focused) Brand.accent else Brand.surface)
                            .padding(horizontal = 20.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Txt(g, size = 15, weight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}
