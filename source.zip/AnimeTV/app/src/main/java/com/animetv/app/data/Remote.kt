package com.animetv.app.data

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Un anuncio propio: imagen o video (siempre en mute) servido desde una URL. */
data class AdItem(val type: String, val url: String, val seconds: Int, val text: String = "")

/** Datos de la última versión publicada, para el aviso de actualización. */
data class UpdateInfo(val versionCode: Int, val versionName: String, val apkUrl: String, val notes: String)

/**
 * Configuración remota de la app (config.json en el repo): la lista de
 * anuncios propios y los datos de la última versión. Miguel la edita sin
 * tocar la app: cambia los anuncios o sube la versión y la app lo recoge
 * al arrancar. Si no hay red o el archivo falla, la app sigue como siempre.
 */
object Remote {
    private const val CONFIG_URL =
        "https://raw.githubusercontent.com/elprota21/animetv/main/config.json"

    var ads by mutableStateOf<List<AdItem>>(emptyList())
        private set

    var update by mutableStateOf<UpdateInfo?>(null)
        private set

    private var tried = false

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    suspend fun load() {
        if (tried) return
        tried = true
        runCatching {
            val body = withContext(Dispatchers.IO) {
                val req = Request.Builder().url(CONFIG_URL)
                    .header("User-Agent", "AnimeTV")
                    .build()
                client.newCall(req).execute().use { r ->
                    if (r.isSuccessful) r.body?.string().orEmpty() else ""
                }
            }
            if (body.isBlank()) return
            val root = JSONObject(body)

            val arr = root.optJSONArray("ads")
            if (arr != null) {
                val list = ArrayList<AdItem>()
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val u = o.optString("url")
                    if (u.isNotBlank()) {
                        list.add(AdItem(o.optString("type", "image"), u, o.optInt("seconds", 8), o.optString("text")))
                    }
                }
                ads = list
            }

            val u = root.optJSONObject("update")
            if (u != null && u.optString("apkUrl").isNotBlank()) {
                update = UpdateInfo(
                    u.optInt("versionCode"),
                    u.optString("versionName"),
                    u.optString("apkUrl"),
                    u.optString("notes")
                )
            }
        }
    }
}
