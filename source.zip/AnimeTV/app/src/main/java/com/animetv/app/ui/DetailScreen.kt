package com.animetv.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.animetv.app.data.Account
import com.animetv.app.data.Anime
import com.animetv.app.data.Media
import com.animetv.app.data.Brand
import com.animetv.app.data.Prefs
import com.animetv.app.data.Repo
import com.animetv.app.data.S
import com.animetv.app.data.Season
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun DetailScreen(
    s: S,
    slug: String,
    prefs: Prefs,
    onEpisode: (String, Int, List<Int>) -> Unit,
    onSeason: (String) -> Unit,
    onBack: () -> Unit
) {
    var anime by remember { mutableStateOf<Anime?>(null) }
    var seasons by remember { mutableStateOf<List<Season>>(emptyList()) }
    var focusedSeason by remember { mutableStateOf<Season?>(null) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var attempt by remember { mutableIntStateOf(0) }
    val playFocus = remember { FocusRequester() }

    LaunchedEffect(slug, attempt) {
        loading = true
        error = null
        val r = runCatching { Repo.anime(slug) }
        anime = r.getOrNull()
        error = r.exceptionOrNull()?.message
        loading = false
        if (anime != null) {
            seasons = runCatching { Repo.seasons(slug) }.getOrDefault(emptyList())
        }
    }

    LaunchedEffect(loading, anime) {
        if (!loading && anime != null) {
            delay(250)
            runCatching { playFocus.requestFocus() }
        }
    }

    val a = anime

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Brand.bg2, Brand.bg)))) {
        if (a != null && a.cover.isNotEmpty()) {
            AsyncImage(
                model = a.cover,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                alpha = 0.28f,
                modifier = Modifier.fillMaxWidth().fillMaxHeight(0.6f)
            )
        }
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(0.1f to Color.Transparent, 0.5f to Brand.bg)
            )
        )

        when {
            loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Spinner() }

            a == null -> Column(
                Modifier.fillMaxSize().padding(if (compactWidth()) 16.dp else 48.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Txt(s.loadError, size = 22, weight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Txt(error ?: s.noResults, size = 13, color = Brand.muted)
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    TvButton(s.retry, { attempt++ }, primary = true)
                    TvButton(s.back, onBack)
                }
            }

            else -> {
                val resumeEp = a.episodes.firstOrNull { prefs.hasProgress("$slug-${it.number}") }
                val playEp = resumeEp ?: a.episodes.firstOrNull()

                Column(Modifier.fillMaxSize()) {
                    Row(
                        Modifier.fillMaxWidth().padding(start = if (compactWidth()) 0.dp else 40.dp, end = sideEnd(), top = 26.dp),
                        horizontalArrangement = Arrangement.spacedBy(20.dp)
                    ) {
                        AsyncImage(
                            model = a.cover,
                            contentDescription = a.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.width(120.dp).height(180.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Brand.surface)
                        )
                        Column(Modifier.weight(1f)) {
                            Txt(a.title, size = 28, weight = FontWeight.Bold, maxLines = 2, lineHeight = 32)
                            Spacer(Modifier.height(8.dp))
                            MetaChips(a)
                            Spacer(Modifier.height(10.dp))
                            if (a.synopsis.isNotEmpty()) {
                                Txt(a.synopsis, size = 14, maxLines = 3, lineHeight = 20)
                            }
                            Spacer(Modifier.height(14.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                if (playEp != null) {
                                    val label = if (resumeEp != null) s.resume else s.play
                                    TvButton(
                                        "$label · ${s.episode} ${playEp.number}",
                                        { onEpisode(a.title, playEp.number, a.episodes.map { it.number }) },
                                        primary = true,
                                        focusRequester = playFocus
                                    )
                                }
                                TvButton(s.back, onBack)
                            }
                            Spacer(Modifier.height(10.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                var liked by remember(slug) { mutableStateOf(prefs.isLiked(slug)) }
                                var saved by remember(slug) { mutableStateOf(prefs.isSaved(slug)) }
                                val scope = rememberCoroutineScope()
                                TvButton(
                                    if (liked) "♥ ${s.liked}" else "♡ ${s.like}",
                                    {
                                        liked = prefs.toggleLike(slug)
                                        val nowLiked = liked
                                        scope.launch {
                                            runCatching { Account.setLike(slug, a.title, nowLiked) }
                                        }
                                    }
                                )
                                TvButton(
                                    if (saved) s.inList else s.addList,
                                    { saved = prefs.toggleSaved(Media(a.title, a.cover, slug, slug, "poster", 0)) }
                                )
                            }
                        }
                    }

                    // Selector de temporadas (solo si hay mas de una)
                    if (seasons.size > 1) {
                        Spacer(Modifier.height(12.dp))
                        Row(
                            Modifier.padding(horizontal = 40.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Txt(s.seasons, size = 16, weight = FontWeight.Bold)
                            Spacer(Modifier.width(12.dp))
                            Txt(
                                (focusedSeason ?: seasons.firstOrNull { it.slug == a.slug })?.title.orEmpty(),
                                size = 13,
                                color = Brand.muted,
                                maxLines = 1
                            )
                        }
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 40.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            itemsIndexed(seasons) { i, se ->
                                val current = se.slug == a.slug
                                FocusSurface(
                                    onClick = { if (!current) onSeason(se.slug) },
                                    onFocused = { focusedSeason = se },
                                    modifier = Modifier.height(40.dp),
                                    shape = RoundedCornerShape(50),
                                    focusScale = 1.06f
                                ) { focused ->
                                    Row(
                                        Modifier.fillMaxHeight()
                                            .background(
                                                when {
                                                    focused -> Brand.accent
                                                    current -> Color(0xFF5B3BC4)
                                                    else -> Brand.surface
                                                }
                                            )
                                            .padding(horizontal = 18.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Txt("${s.season} ${i + 1}", size = 14, weight = FontWeight.SemiBold)
                                        if (se.year > 0) {
                                            Spacer(Modifier.width(8.dp))
                                            Txt(se.year.toString(), size = 12, color = Brand.muted)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(Modifier.height(6.dp))
                    Txt(
                        "${s.episodes} (${a.episodes.size})",
                        size = 18,
                        weight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 40.dp)
                    )

                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(92.dp),
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(horizontal = 40.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(a.episodes) { ep ->
                            val seen = prefs.hasProgress("$slug-${ep.number}")
                            val watched = prefs.isWatched("$slug-${ep.number}")
                            FocusSurface(
                                onClick = { onEpisode(a.title, ep.number, a.episodes.map { it.number }) },
                                modifier = Modifier.fillMaxWidth().height(44.dp),
                                shape = RoundedCornerShape(10.dp),
                                focusScale = 1.08f
                            ) { focused ->
                                Box(
                                    Modifier.fillMaxSize().background(
                                        when {
                                            focused -> Brand.accent
                                            watched -> Color(0xFF0E3A3A)
                                            seen -> Color(0x558B5CFF)
                                            else -> Brand.surface
                                        }
                                    ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Txt(
                                        if (watched) "EP ${ep.number} ✓" else "EP ${ep.number}",
                                        size = 14,
                                        weight = FontWeight.SemiBold,
                                        align = TextAlign.Center
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
