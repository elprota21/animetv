package com.animetv.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.animetv.app.data.Brand
import com.animetv.app.data.S

enum class Tab { Home, Catalog, Kids, Search, Settings }

/** Marco comun: menu lateral a la izquierda y tu logo arriba a la derecha. */
@Composable
fun Shell(s: S, tab: Tab, onTab: (Tab) -> Unit, content: @Composable BoxScope.() -> Unit) {
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Brand.bg2, Brand.bg)))) {
        Row(Modifier.fillMaxSize()) {
            Rail(s, tab, onTab)
            Box(Modifier.weight(1f).fillMaxHeight(), content = content)
        }
        Logo(Modifier.align(Alignment.TopEnd).padding(top = 14.dp, end = 20.dp), 44.dp)
    }
}

@Composable
private fun Rail(s: S, tab: Tab, onTab: (Tab) -> Unit) {
    Column(
        Modifier.width(150.dp).fillMaxHeight()
            .background(Color(0x33000000))
            .padding(vertical = 22.dp, horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        val nameParts = Brand.appName.split(" ", limit = 2)
        Row(Modifier.padding(start = 6.dp, bottom = 18.dp)) {
            Txt(nameParts[0], size = 20, weight = FontWeight.Bold)
            if (nameParts.size > 1) Txt(nameParts[1], size = 20, weight = FontWeight.Bold, color = Brand.cyan)
        }
        RailItem(s.home, tab == Tab.Home) { onTab(Tab.Home) }
        RailItem(s.catalog, tab == Tab.Catalog) { onTab(Tab.Catalog) }
        RailItem(s.kids, tab == Tab.Kids) { onTab(Tab.Kids) }
        RailItem(s.search, tab == Tab.Search) { onTab(Tab.Search) }
        RailItem(s.settings, tab == Tab.Settings) { onTab(Tab.Settings) }
    }
}

@Composable
private fun RailItem(label: String, selected: Boolean, onClick: () -> Unit) {
    FocusSurface(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().height(44.dp),
        shape = RoundedCornerShape(12.dp),
        focusScale = 1.04f
    ) { focused ->
        Row(
            Modifier.fillMaxSize()
                .background(if (focused) Brand.accent else if (selected) Color(0x33FFFFFF) else Color.Transparent)
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.width(4.dp).height(20.dp)
                    .background(if (selected) Brand.cyan else Color.Transparent, RoundedCornerShape(2.dp))
            )
            Spacer(Modifier.width(10.dp))
            Txt(label, size = 16, weight = FontWeight.SemiBold)
        }
    }
}
