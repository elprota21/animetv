package com.animetv.app.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * Cuentas y «me gusta» con servidor (Supabase, REST puro).
 * La sesion vive en SharedPreferences; cada usuario solo puede tocar sus filas (RLS).
 */
object Account {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()
    private val JSON = "application/json".toMediaType()

    private lateinit var sp: SharedPreferences

    fun init(ctx: Context) {
        sp = ctx.getSharedPreferences("account", Context.MODE_PRIVATE)
    }

    fun email(): String = sp.getString("email", "") ?: ""
    fun userId(): String = sp.getString("uid", "") ?: ""
    fun isLoggedIn(): Boolean =
        (sp.getString("access", "") ?: "").isNotEmpty() && userId().isNotEmpty()

    fun isAdmin(): Boolean = email().lowercase() in Brand.adminEmails

    // ---------- sesion ----------

    private fun saveSession(o: JSONObject) {
        val user = o.optJSONObject("user")
        val expiresIn = o.optLong("expires_in", 3600)
        sp.edit()
            .putString("access", o.optString("access_token"))
            .putString("refresh", o.optString("refresh_token"))
            .putLong("expiresAt", System.currentTimeMillis() + expiresIn * 1000)
            .putString("uid", user?.optString("id") ?: userId())
            .putString("email", user?.optString("email") ?: email())
            .apply()
    }

    private fun clearSession() {
        sp.edit().clear().apply()
    }

    private suspend fun authPost(path: String, body: JSONObject): JSONObject =
        withContext(Dispatchers.IO) {
            val req = Request.Builder()
                .url(Brand.supabaseUrl + path)
                .header("apikey", Brand.supabaseAnon)
                .header("Content-Type", "application/json")
                .post(body.toString().toRequestBody(JSON))
                .build()
            client.newCall(req).execute().use { r ->
                val txt = r.body?.string().orEmpty()
                val o = runCatching { JSONObject(txt) }.getOrNull() ?: JSONObject()
                if (!r.isSuccessful) {
                    val msg = o.optString("msg", o.optString("message", "HTTP ${r.code}"))
                    throw ApiException(msg)
                }
                o
            }
        }

    /** Devuelve null si todo va bien, o el mensaje de error para mostrarlo. */
    suspend fun signUp(email: String, password: String): String? {
        return try {
            val o = authPost(
                "/auth/v1/signup",
                JSONObject().put("email", email).put("password", password)
            )
            if (o.optString("access_token").isNotEmpty()) {
                saveSession(o)
                null
            } else {
                "Cuenta creada, pero sin sesion: entra con «Iniciar sesion»."
            }
        } catch (e: Exception) {
            e.message ?: "Error"
        }
    }

    /** Devuelve null si todo va bien, o el mensaje de error para mostrarlo. */
    suspend fun signIn(email: String, password: String): String? = runCatching {
        val o = authPost(
            "/auth/v1/token?grant_type=password",
            JSONObject().put("email", email).put("password", password)
        )
        saveSession(o)
        null
    }.getOrElse { it.message ?: "Error" }

    suspend fun signOut() {
        val token = sp.getString("access", "") ?: ""
        if (token.isNotEmpty()) runCatching {
            withContext(Dispatchers.IO) {
                val req = Request.Builder()
                    .url(Brand.supabaseUrl + "/auth/v1/logout")
                    .header("apikey", Brand.supabaseAnon)
                    .header("Authorization", "Bearer $token")
                    .post("{}".toRequestBody(JSON))
                    .build()
                client.newCall(req).execute().use { }
            }
        }
        clearSession()
    }

    private suspend fun freshToken(): String {
        val expiresAt = sp.getLong("expiresAt", 0)
        val token = sp.getString("access", "") ?: ""
        if (token.isEmpty()) return ""
        if (System.currentTimeMillis() < expiresAt - 60_000) return token
        val refresh = sp.getString("refresh", "") ?: ""
        if (refresh.isEmpty()) return token
        return runCatching {
            val o = authPost(
                "/auth/v1/token?grant_type=refresh_token",
                JSONObject().put("refresh_token", refresh)
            )
            saveSession(o)
            o.optString("access_token")
        }.getOrDefault(token)
    }

    // ---------- REST (datos) ----------

    private suspend fun rest(
        method: String,
        path: String,
        body: JSONObject? = null
    ): String = withContext(Dispatchers.IO) {
        val token = freshToken()
        val b = Request.Builder()
            .url(Brand.supabaseUrl + "/rest/v1" + path)
            .header("apikey", Brand.supabaseAnon)
            .header("Authorization", "Bearer $token")
            .header("Content-Type", "application/json")
        when (method) {
            "POST" -> b.post((body ?: JSONObject()).toString().toRequestBody(JSON))
                .header("Prefer", "return=minimal")
            "DELETE" -> b.delete()
            else -> b.get()
        }
        client.newCall(b.build()).execute().use { r ->
            val txt = r.body?.string().orEmpty()
            if (!r.isSuccessful) throw ApiException("HTTP ${r.code}: $txt")
            txt
        }
    }

    private fun enc(x: String): String = URLEncoder.encode(x, "UTF-8")

    // ---------- me gusta de animes ----------

    suspend fun myLikes(): Set<String> = runCatching {
        val arr = JSONArray(rest("GET", "/likes?select=anime_slug"))
        (0 until arr.length()).map { arr.getJSONObject(it).optString("anime_slug") }.toSet()
    }.getOrDefault(emptySet())

    suspend fun setLike(slug: String, title: String, on: Boolean) {
        if (on) {
            runCatching {
                rest(
                    "POST", "/likes",
                    JSONObject()
                        .put("user_id", userId())
                        .put("anime_slug", slug)
                        .put("anime_title", title)
                )
            }
        } else {
            runCatching { rest("DELETE", "/likes?anime_slug=eq.${enc(slug)}") }
        }
    }

    // ---------- me gusta de capitulos ----------

    /** Claves "slug#episodio". */
    suspend fun myEpisodeLikes(): Set<String> = runCatching {
        val arr = JSONArray(rest("GET", "/episode_likes?select=anime_slug,episode"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            "${o.optString("anime_slug")}#${o.optInt("episode")}"
        }.toSet()
    }.getOrDefault(emptySet())

    suspend fun setEpisodeLike(slug: String, episode: Int, on: Boolean) {
        if (on) {
            runCatching {
                rest(
                    "POST", "/episode_likes",
                    JSONObject()
                        .put("user_id", userId())
                        .put("anime_slug", slug)
                        .put("episode", episode)
                )
            }
        } else {
            runCatching {
                rest("DELETE", "/episode_likes?anime_slug=eq.${enc(slug)}&episode=eq.$episode")
            }
        }
    }

    // ---------- rankings (panel de administrador) ----------

    data class TopAnime(val slug: String, val title: String, val likes: Int)
    data class TopEpisode(val slug: String, val episode: Int, val likes: Int)

    suspend fun topAnimes(limit: Int = 20): List<TopAnime> = runCatching {
        val arr = JSONArray(
            rest("GET", "/like_counts?select=anime_slug,anime_title,likes&order=likes.desc&limit=$limit")
        )
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            TopAnime(o.optString("anime_slug"), o.optString("anime_title"), o.optInt("likes"))
        }
    }.getOrDefault(emptyList())

    suspend fun topEpisodes(limit: Int = 20): List<TopEpisode> = runCatching {
        val arr = JSONArray(
            rest("GET", "/episode_like_counts?select=anime_slug,episode,likes&order=likes.desc&limit=$limit")
        )
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            TopEpisode(o.optString("anime_slug"), o.optInt("episode"), o.optInt("likes"))
        }
    }.getOrDefault(emptyList())
}
