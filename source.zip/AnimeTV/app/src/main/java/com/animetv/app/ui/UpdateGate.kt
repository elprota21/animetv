package com.animetv.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.animetv.app.data.Brand
import com.animetv.app.data.Remote
import com.animetv.app.data.S
import com.animetv.app.data.Updater
import kotlinx.coroutines.launch

/**
 * Aviso de actualización dentro de la app: si config.json anuncia una
 * versión más nueva que la instalada, ofrece descargarla e instalarla
 * sin salir de la app (Android pide una sola vez el permiso de instalar).
 */
@Composable
fun UpdateGate(s: S) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val upd = Remote.update

    var dismissed by remember { mutableStateOf(false) }
    var downloading by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(-1) }

    if (upd == null || dismissed) return
    val current = remember { Updater.currentCode(ctx) }
    if (upd.versionCode <= current) return

    Box(
        Modifier.fillMaxSize().background(Color(0xCC05030F)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier.width(520.dp)
                .background(Brand.surface, RoundedCornerShape(18.dp))
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Txt("⬆ ${s.updateAvailable}", size = 22, weight = FontWeight.Bold, align = TextAlign.Center)
            Spacer(Modifier.height(6.dp))
            Txt("AnimeTV ${upd.versionName}", size = 16, color = Brand.cyan, weight = FontWeight.SemiBold)
            if (upd.notes.isNotBlank()) {
                Spacer(Modifier.height(10.dp))
                Txt(upd.notes, size = 14, color = Brand.muted, align = TextAlign.Center)
            }
            Spacer(Modifier.height(20.dp))

            if (downloading) {
                Txt(
                    if (progress >= 0) "${s.updateDownloading} $progress%" else s.updateDownloading,
                    size = 15, color = Brand.muted, align = TextAlign.Center
                )
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    TvButton(s.updateNow, {
                        if (!Updater.canInstall(ctx)) {
                            // Primera vez: Android pide permitir instalar desde esta app.
                            Updater.openInstallSettings(ctx)
                        } else {
                            downloading = true
                            progress = -1
                            scope.launch {
                                val f = runCatching {
                                    Updater.download(ctx, upd.apkUrl) { p -> progress = p }
                                }.getOrNull()
                                downloading = false
                                if (f != null) {
                                    Updater.install(ctx, f)
                                    dismissed = true
                                }
                            }
                        }
                    }, primary = true)
                    TvButton(s.updateLater, { dismissed = true })
                }
                if (!Updater.canInstall(ctx)) {
                    Spacer(Modifier.height(10.dp))
                    Txt(s.updateAllow, size = 12, color = Brand.muted, align = TextAlign.Center)
                }
            }
        }
    }
}
